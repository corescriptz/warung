-- Backup Warung Jaya - 2026-11-07 22:12:45
-- Dibuat otomatis oleh Warung Kelontong POS

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `pengaturan`;
CREATE TABLE `pengaturan` (
  `kunci` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nilai` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`kunci`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('auto_backup','1');
INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('backup_terakhir','2026-11-07 21:37:18');
INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('kasir_nama','Pak Joko');
INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('printer_lebar','80');
INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('printer_nama','POS-58 Thermal');
INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('struk_footer','Terima kasih telah berbelanja!');
INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('toko_alamat','Jl. Merdeka No. 123, Jakarta');
INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('toko_nama','Warung Jaya');
INSERT INTO `pengaturan` (`kunci`,`nilai`) VALUES ('toko_telp','0812-3456-7890');

DROP TABLE IF EXISTS `kategori`;
CREATE TABLE `kategori` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `kategori` (`id`,`nama`) VALUES ('5','Lainnya');
INSERT INTO `kategori` (`id`,`nama`) VALUES ('2','Minuman');
INSERT INTO `kategori` (`id`,`nama`) VALUES ('4','Rokok');
INSERT INTO `kategori` (`id`,`nama`) VALUES ('1','Sembako');
INSERT INTO `kategori` (`id`,`nama`) VALUES ('3','Snack');

DROP TABLE IF EXISTS `produk`;
CREATE TABLE `produk` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori_id` int unsigned DEFAULT NULL,
  `satuan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pcs',
  `barcode` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `harga_beli` decimal(12,2) NOT NULL DEFAULT '0.00',
  `harga_jual` decimal(12,2) NOT NULL DEFAULT '0.00',
  `stok` int NOT NULL DEFAULT '0',
  `stok_minimal` int NOT NULL DEFAULT '5',
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `dibuat_pada` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_barcode` (`barcode`),
  KEY `idx_nama` (`nama`),
  KEY `idx_kategori` (`kategori_id`),
  CONSTRAINT `fk_produk_kategori` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('1','Beras Pandan Wangi 5kg','1','sak',NULL,'65000.00','72000.00','12','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('2','Beras Ramos 5kg','1','sak',NULL,'58000.00','65000.00','15','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('3','Minyak Goreng 2x1L','1','pouch',NULL,'34000.00','39000.00','8','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('4','Gula Pasir 1kg','1','kg',NULL,'15500.00','18000.00','20','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('5','Telur Ayam 1kg','1','kg',NULL,'26000.00','29500.00','18','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('6','Kecap Manis Bango 135ml','1','botol',NULL,'17500.00','21000.00','6','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('7','Tepung Segitiga Biru 1kg','1','kg',NULL,'12000.00','14500.00','10','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('8','Indomie Goreng','1','pcs',NULL,'2800.00','3500.00','72','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('9','Aqua 600ml','2','botol',NULL,'2800.00','3500.00','54','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('10','Teh Pucuk Harum 350ml','2','botol',NULL,'3000.00','4000.00','36','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('11','Kopi Kapal Api Special','2','sachet',NULL,'1500.00','2000.00','60','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('12','Susu Ultra Milk Coklat 250ml','2','kotak',NULL,'5500.00','7000.00','24','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('13','Le Minerale 1500ml','2','botol',NULL,'5000.00','6500.00','20','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('14','Chitato Sapi Panggang 68g','3','pcs',NULL,'8500.00','11000.00','15','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('15','Oreo Vanilla 133g','3','pcs',NULL,'7500.00','9500.00','18','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('16','SilverQueen Chunky Bar','3','pcs',NULL,'14000.00','18000.00','9','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('17','Beng-Beng','3','pcs',NULL,'1500.00','2000.00','49','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('18','Tango Wafer Coklat','3','pcs',NULL,'8000.00','10000.00','14','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('19','Sampoerna Mild 12','4','bks',NULL,'27000.00','30500.00','11','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('20','Gudang Garam Surya 12','4','bks',NULL,'30000.00','33500.00','9','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('21','Marlboro Red 20','4','bks',NULL,'32000.00','36500.00','7','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('22','Djarum Super 12','4','bks',NULL,'28500.00','31500.00','10','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('23','Sabun Lifebuoy 250ml','5','botol',NULL,'14000.00','17500.00','12','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('24','Deterjen Rinso 800g','5','pcs',NULL,'18000.00','22500.00','10','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('25','Pasta Gigi Pepsodent 190g','5','pcs',NULL,'13000.00','16500.00','11','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('26','Baterai ABC AA (2 pcs)','5','pack',NULL,'7000.00','9000.00','20','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('27','Gas LPG 3kg','5','tabung',NULL,'18000.00','22000.00','6','5','0','1','2026-11-07 13:39:39');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('38','Gula Merah 1kg','1','kg',NULL,'18.00','22.50','6','5','1','1','2026-11-07 14:32:21');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('39','Kopi Gula Aren Botol','2','botol',NULL,'8500.00','12000.00','9','5','1','1','2026-11-07 14:32:21');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('40','Sabun Lifebuoy','5','biji',NULL,'2800.00','3500.00','12','5','1','1','2026-11-07 21:39:41');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('41','Shampo Sachet','5','sacet',NULL,'1500.00','2000.00','1','5','1','1','2026-11-07 21:39:41');
INSERT INTO `produk` (`id`,`nama`,`kategori_id`,`satuan`,`barcode`,`harga_beli`,`harga_jual`,`stok`,`stok_minimal`,`is_new`,`aktif`,`dibuat_pada`) VALUES ('42','Pepsodent 190g','5','biji',NULL,'27000.00','30500.00','5','5','1','1','2026-11-07 21:39:42');

DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE `transaksi` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` datetime NOT NULL,
  `subtotal` decimal(14,2) NOT NULL DEFAULT '0.00',
  `diskon` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `bayar` decimal(14,2) NOT NULL DEFAULT '0.00',
  `kembalian` decimal(14,2) NOT NULL DEFAULT '0.00',
  `metode` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Tunai',
  `laba` decimal(14,2) NOT NULL DEFAULT '0.00',
  `kasir` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Kasir',
  `catatan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kode` (`kode`),
  KEY `idx_tanggal` (`tanggal`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('1','TRX-20261107-0001','2026-11-07 19:39:39','21000.00','0.00','21000.00','21000.00','0.00','Tunai','3500.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('2','TRX-20261107-0002','2026-11-07 18:39:39','9000.00','0.00','9000.00','9000.00','0.00','Tunai','1900.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('3','TRX-20261107-0003','2026-11-07 17:39:39','25500.00','0.00','25500.00','50000.00','24500.00','Tunai','5500.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('4','TRX-20261107-0004','2026-11-07 15:39:39','72000.00','0.00','72000.00','72000.00','0.00','Tunai','7000.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('5','TRX-20261107-0005','2026-11-07 13:39:39','34000.00','0.00','34000.00','50000.00','16000.00','Tunai','4200.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('6','TRX-20261107-0006','2026-11-07 11:39:39','78000.00','0.00','78000.00','78000.00','0.00','QRIS','10000.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('7','TRX-20261107-0007','2026-11-07 09:39:39','15500.00','0.00','15500.00','20000.00','4500.00','Tunai','3500.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('8','TRX-20261107-0008','2026-11-07 00:39:39','65500.00','0.00','65500.00','100000.00','34500.00','Tunai','8500.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('9','TRX-20261106-0009','2026-11-06 21:39:39','25000.00','0.00','25000.00','50000.00','25000.00','Tunai','5500.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('10','TRX-20261106-0010','2026-11-06 18:39:39','35000.00','0.00','35000.00','35000.00','0.00','Tunai','7000.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('11','TRX-20261106-0011','2026-11-06 14:39:39','33500.00','0.00','33500.00','33500.00','0.00','QRIS','3500.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('12','TRX-20261106-0012','2026-11-06 10:39:39','34000.00','0.00','34000.00','50000.00','16000.00','Tunai','7000.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('13','TRX-20261105-0013','2026-11-05 22:39:39','104000.00','0.00','104000.00','200000.00','96000.00','Tunai','12000.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('14','TRX-20261105-0014','2026-11-05 18:39:39','17000.00','0.00','17000.00','17000.00','0.00','Tunai','4000.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('15','TRX-20261105-0015','2026-11-05 14:39:39','31500.00','0.00','31500.00','50000.00','18500.00','Tunai','6500.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('16','TRX-20261105-0016','2026-11-05 10:39:39','43500.00','0.00','43500.00','43500.00','0.00','Tunai','5900.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('17','TRX-20261104-0017','2026-11-04 22:39:39','73500.00','0.00','73500.00','100000.00','26500.00','Tunai','9500.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('18','TRX-20261104-0018','2026-11-04 17:39:39','10000.00','0.00','10000.00','10000.00','0.00','Tunai','2500.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('19','TRX-20261104-0019','2026-11-04 12:39:39','28000.00','0.00','28000.00','50000.00','22000.00','Tunai','6000.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('20','TRX-20261103-0020','2026-11-03 22:39:39','61000.00','0.00','61000.00','61000.00','0.00','QRIS','7000.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('21','TRX-20261103-0021','2026-11-03 16:39:39','25500.00','0.00','25500.00','25500.00','0.00','Tunai','4700.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('22','TRX-20261102-0022','2026-11-02 22:39:39','39500.00','0.00','39500.00','50000.00','10500.00','Tunai','5000.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('23','TRX-20261102-0023','2026-11-02 10:39:39','144000.00','0.00','144000.00','200000.00','56000.00','Tunai','14000.00','Andi',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('24','TRX-20261101-0024','2026-11-01 22:39:39','37000.00','0.00','37000.00','37000.00','0.00','Tunai','8000.00','Bu Rina',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('25','TRX-20261107-0025','2026-11-07 20:52:43','7000.00','0.00','7000.00','10000.00','3000.00','Tunai','1400.00','Tester',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('26','TRX-20261107-0026','2026-11-07 20:53:57','7000.00','0.00','7000.00','10000.00','3000.00','Tunai','1400.00','Tester',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('27','TRX-20261107-0027','2026-11-07 20:54:27','8000.00','0.00','8000.00','10000.00','2000.00','Tunai','2200.00','Tester',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('28','TRX-20261107-0028','2026-11-07 21:20:02','8000.00','0.00','8000.00','10000.00','2000.00','Tunai','2200.00','Tester',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('29','TRX-20261107-0029','2026-11-07 21:20:02','4000.00','0.00','4000.00','4000.00','0.00','QRIS','1100.00','Pak Joko',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('30','TRX-20261107-0030','2026-11-07 21:20:43','7000.00','0.00','7000.00','10000.00','3000.00','Tunai','1400.00','Tester',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('31','TRX-20261107-0031','2026-11-07 21:20:43','3500.00','0.00','3500.00','3500.00','0.00','QRIS','700.00','Pak Joko',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('32','TRX-20261107-0032','2026-11-07 21:24:46','7000.00','0.00','7000.00','10000.00','3000.00','Tunai','1400.00','Tester',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('33','TRX-20261107-0033','2026-11-07 21:24:46','3500.00','0.00','3500.00','3500.00','0.00','QRIS','700.00','Pak Joko',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('34','TRX-20261107-0034','2026-11-07 21:32:21','7000.00','0.00','7000.00','10000.00','3000.00','Tunai','1400.00','Tester',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('35','TRX-20261107-0035','2026-11-07 21:32:21','3500.00','0.00','3500.00','3500.00','0.00','QRIS','700.00','Pak Joko',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('36','TRX-20261107-0036','2026-11-07 21:33:18','10000.00','0.00','10000.00','10000.00','0.00','Tunai','2700.00','Pak Joko',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('37','TRX-20261107-0037','2026-11-07 21:33:33','4000.00','0.00','4000.00','4000.00','0.00','QRIS','1100.00','Pak Joko',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('38','TRX-20261107-0038','2026-11-07 21:34:16','7000.00','0.00','7000.00','10000.00','3000.00','Tunai','1400.00','Tester',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('39','TRX-20261107-0039','2026-11-07 21:34:17','3500.00','0.00','3500.00','3500.00','0.00','QRIS','700.00','Pak Joko',NULL);
INSERT INTO `transaksi` (`id`,`kode`,`tanggal`,`subtotal`,`diskon`,`total`,`bayar`,`kembalian`,`metode`,`laba`,`kasir`,`catatan`) VALUES ('40','TRX-20261107-0040','2026-11-07 21:38:04','22.50','0.00','22.50','50000.00','49977.50','Tunai','4.50','Pak Joko',NULL);

DROP TABLE IF EXISTS `transaksi_detail`;
CREATE TABLE `transaksi_detail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaksi_id` int unsigned NOT NULL,
  `produk_id` int unsigned DEFAULT NULL,
  `nama_produk` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `satuan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pcs',
  `harga_beli` decimal(12,2) NOT NULL DEFAULT '0.00',
  `harga_jual` decimal(12,2) NOT NULL DEFAULT '0.00',
  `qty` int NOT NULL DEFAULT '0',
  `subtotal` decimal(14,2) NOT NULL DEFAULT '0.00',
  `laba` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_transaksi` (`transaksi_id`),
  KEY `idx_produk` (`produk_id`),
  CONSTRAINT `fk_detail_produk` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_detail_transaksi` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('1','1','6','Kecap Manis Bango 135ml','botol','17500.00','21000.00','1','21000.00','3500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('2','2','9','Aqua 600ml','botol','2800.00','3500.00','2','7000.00','1400.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('3','2','11','Kopi Kapal Api Special','sachet','1500.00','2000.00','1','2000.00','500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('4','3','8','Indomie Goreng','pcs','2800.00','3500.00','5','17500.00','3500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('5','3','10','Teh Pucuk Harum 350ml','botol','3000.00','4000.00','2','8000.00','2000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('6','4','1','Beras Pandan Wangi 5kg','sak','65000.00','72000.00','1','72000.00','7000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('7','5','19','Sampoerna Mild 12','bks','27000.00','30500.00','1','30500.00','3500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('8','5','9','Aqua 600ml','botol','2800.00','3500.00','1','3500.00','700.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('9','6','3','Minyak Goreng 2x1L','pouch','34000.00','39000.00','2','78000.00','10000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('10','7','17','Beng-Beng','pcs','1500.00','2000.00','3','6000.00','1500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('11','7','15','Oreo Vanilla 133g','pcs','7500.00','9500.00','1','9500.00','2000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('12','8','4','Gula Pasir 1kg','kg','15500.00','18000.00','2','36000.00','5000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('13','8','5','Telur Ayam 1kg','kg','26000.00','29500.00','1','29500.00','3500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('14','9','14','Chitato Sapi Panggang 68g','pcs','8500.00','11000.00','1','11000.00','2500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('15','9','12','Susu Ultra Milk Coklat 250ml','kotak','5500.00','7000.00','2','14000.00','3000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('16','10','8','Indomie Goreng','pcs','2800.00','3500.00','10','35000.00','7000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('17','11','20','Gudang Garam Surya 12','bks','30000.00','33500.00','1','33500.00','3500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('18','12','23','Sabun Lifebuoy 250ml','botol','14000.00','17500.00','1','17500.00','3500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('19','12','25','Pasta Gigi Pepsodent 190g','pcs','13000.00','16500.00','1','16500.00','3500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('20','13','2','Beras Ramos 5kg','sak','58000.00','65000.00','1','65000.00','7000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('21','13','3','Minyak Goreng 2x1L','pouch','34000.00','39000.00','1','39000.00','5000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('22','14','13','Le Minerale 1500ml','botol','5000.00','6500.00','2','13000.00','3000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('23','14','17','Beng-Beng','pcs','1500.00','2000.00','2','4000.00','1000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('24','15','24','Deterjen Rinso 800g','pcs','18000.00','22500.00','1','22500.00','4500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('25','15','26','Baterai ABC AA (2 pcs)','pack','7000.00','9000.00','1','9000.00','2000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('26','16','21','Marlboro Red 20','bks','32000.00','36500.00','1','36500.00','4500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('27','16','9','Aqua 600ml','botol','2800.00','3500.00','2','7000.00','1400.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('28','17','5','Telur Ayam 1kg','kg','26000.00','29500.00','2','59000.00','7000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('29','17','7','Tepung Segitiga Biru 1kg','kg','12000.00','14500.00','1','14500.00','2500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('30','18','11','Kopi Kapal Api Special','sachet','1500.00','2000.00','5','10000.00','2500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('31','19','16','SilverQueen Chunky Bar','pcs','14000.00','18000.00','1','18000.00','4000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('32','19','18','Tango Wafer Coklat','pcs','8000.00','10000.00','1','10000.00','2000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('33','20','19','Sampoerna Mild 12','bks','27000.00','30500.00','2','61000.00','7000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('34','21','27','Gas LPG 3kg','tabung','18000.00','22000.00','1','22000.00','4000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('35','21','9','Aqua 600ml','botol','2800.00','3500.00','1','3500.00','700.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('36','22','22','Djarum Super 12','bks','28500.00','31500.00','1','31500.00','3000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('37','22','10','Teh Pucuk Harum 350ml','botol','3000.00','4000.00','2','8000.00','2000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('38','23','1','Beras Pandan Wangi 5kg','sak','65000.00','72000.00','2','144000.00','14000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('39','24','15','Oreo Vanilla 133g','pcs','7500.00','9500.00','2','19000.00','4000.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('40','24','14','Chitato Sapi Panggang 68g','pcs','8500.00','11000.00','1','11000.00','2500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('41','24','12','Susu Ultra Milk Coklat 250ml','kotak','5500.00','7000.00','1','7000.00','1500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('42','25','9','Aqua 600ml','botol','2800.00','3500.00','2','7000.00','1400.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('43','26','9','Aqua 600ml','botol','2800.00','3500.00','2','7000.00','1400.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('44','27','9','Aqua 600ml','botol','2900.00','4000.00','2','8000.00','2200.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('45','28','9','Aqua 600ml','botol','2900.00','4000.00','2','8000.00','2200.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('46','29','9','Aqua 600ml','botol','2900.00','4000.00','1','4000.00','1100.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('47','30','9','Aqua 600ml','botol','2800.00','3500.00','2','7000.00','1400.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('48','31','9','Aqua 600ml','botol','2800.00','3500.00','1','3500.00','700.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('49','32','9','Aqua 600ml','botol','2800.00','3500.00','2','7000.00','1400.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('50','33','9','Aqua 600ml','botol','2800.00','3500.00','1','3500.00','700.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('51','34','9','Aqua 600ml','botol','2800.00','3500.00','2','7000.00','1400.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('52','35','9','Aqua 600ml','botol','2800.00','3500.00','1','3500.00','700.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('53','36','9','Aqua 600ml','botol','2900.00','4000.00','2','8000.00','2200.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('54','36','17','Beng-Beng','pcs','1500.00','2000.00','1','2000.00','500.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('55','37','9','Aqua 600ml','botol','2900.00','4000.00','1','4000.00','1100.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('56','38','9','Aqua 600ml','botol','2800.00','3500.00','2','7000.00','1400.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('57','39','9','Aqua 600ml','botol','2800.00','3500.00','1','3500.00','700.00');
INSERT INTO `transaksi_detail` (`id`,`transaksi_id`,`produk_id`,`nama_produk`,`satuan`,`harga_beli`,`harga_jual`,`qty`,`subtotal`,`laba`) VALUES ('58','40','38','Gula Merah 1kg','kg','18.00','22.50','1','22.50','4.50');

DROP TABLE IF EXISTS `import_log`;
CREATE TABLE `import_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nama_file` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_row` int NOT NULL DEFAULT '0',
  `jumlah_baru` int NOT NULL DEFAULT '0',
  `jumlah_update` int NOT NULL DEFAULT '0',
  `jumlah_gagal` int NOT NULL DEFAULT '0',
  `dibuat_pada` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `import_log` (`id`,`nama_file`,`total_row`,`jumlah_baru`,`jumlah_update`,`jumlah_gagal`,`dibuat_pada`) VALUES ('6','uji-import.xlsx','4','2','1','1','2026-11-07 14:32:21');
INSERT INTO `import_log` (`id`,`nama_file`,`total_row`,`jumlah_baru`,`jumlah_update`,`jumlah_gagal`,`dibuat_pada`) VALUES ('7','import-barang.xlsx','3','3','0','0','2026-11-07 21:39:42');

SET FOREIGN_KEY_CHECKS=1;
