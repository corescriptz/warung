<?php
/**
 * API: Import Excel barang
 *  - GET  ?template=1          -> unduh template .xlsx
 *  - POST multipart step=upload-> unggah & baca file, kembalikan kolom + contoh + tebakan pemetaan
 *  - POST json step=run        -> proses per-bagian (25 baris) untuk progress bar
 */
require_once __DIR__ . '/../config.php';
require_once BASE_PATH . '/lib/xlsx_writer.php';
require_once BASE_PATH . '/lib/xlsx_reader.php';

ensure_export_dirs();
$pdo = db();

/* ---------- Template ---------- */
if (isset($_GET['template'])) {
    XlsxWriter::download('template-import-barang.xlsx', [
        [
            'nama'   => 'Barang',
            'widths' => [30, 18, 16, 14, 14, 10, 10],
            'rows'   => [
                ['Nama Barang', 'Barcode', 'Kategori', 'Harga Beli', 'Harga Jual', 'Stok', 'Satuan'],
                ['Beras Pandan Wangi 5kg', '', 'Sembako', 65000, 72000, 12, 'sak'],
                ['Aqua 600ml', '8992696403018', 'Minuman', 2800, 3500, 48, 'botol'],
                ['Kopi Kapal Api Special', '8991001110034', 'Minuman', 1500, 2000, 60, 'sachet'],
                ['Sampoerna Mild 12', '8992821110123', 'Rokok', 27000, 30500, 11, 'bks'],
            ],
        ],
    ]);
}

/* ---------- Helper ---------- */

/** "Rp 12.500", "12500", "12,5" -> 12500.0 (format Indonesia) */
function parse_angka($v): float
{
    if ($v === null) {
        return 0.0;
    }
    if (is_int($v) || is_float($v)) {
        return (float)$v;
    }
    $s = trim((string)$v);
    if ($s === '') {
        return 0.0;
    }
    $neg = false;
    if (strpos($s, '(') !== false && strpos($s, ')') !== false) {
        $neg = true; // (12500) = minus gaya Excel
    }
    $s = preg_replace('/[^0-9,\.]/', '', $s);
    // Koma sebagai desimal gaya Indonesia: 12,5 -> 12.5
    if (strpos($s, ',') !== false && strpos($s, '.') === false) {
        $s = str_replace(',', '.', $s);
    } else {
        $s = str_replace(',', '', $s); // 1,250.5 gaya Inggris
    }
    $n = (float)$s;
    return $neg ? -$n : $n;
}

/** Tebak pemetaan kolom dari nama header */
function tebak_map(array $headers): array
{
    $map = ['nama' => null, 'barcode' => null, 'kategori' => null, 'harga_beli' => null, 'harga_jual' => null, 'stok' => null, 'satuan' => null];
    foreach ($headers as $i => $h) {
        $n = strtolower(trim(preg_replace('/[^a-z0-9 ]/i', '', (string)$h)));
        if ($n === '') {
            continue;
        }
        if ($map['nama'] === null && preg_match('/(nama|produk|barang|item)/', $n) && !preg_match('/kategori/', $n)) {
            $map['nama'] = $i;
        } elseif ($map['barcode'] === null && preg_match('/(barcode|kode bar|bar code|ean|upc)/', $n)) {
            $map['barcode'] = $i;
        } elseif ($map['kategori'] === null && preg_match('/kategori|kelompok|jenis/', $n)) {
            $map['kategori'] = $i;
        } elseif ($map['harga_beli'] === null && preg_match('/(harga\s*beli|h\s*beli|beli|modal|cost)/', $n)) {
            $map['harga_beli'] = $i;
        } elseif ($map['harga_jual'] === null && preg_match('/(harga\s*jual|h\s*jual|harga|jual|price)/', $n)) {
            $map['harga_jual'] = $i;
        } elseif ($map['stok'] === null && preg_match('/(stok|stock|jumlah|qty)/', $n)) {
            $map['stok'] = $i;
        } elseif ($map['satuan'] === null && preg_match('/(satuan|unit|uom)/', $n)) {
            $map['satuan'] = $i;
        }
    }
    return $map;
}

function huruf_kolom(int $i): string
{
    $s = '';
    $i++;
    while ($i > 0) {
        $m = ($i - 1) % 26;
        $s = chr(65 + $m) . $s;
        $i = intdiv($i - 1, 26);
    }
    return $s;
}

/* ---------- Step: upload ---------- */
if (isset($_POST['step']) && $_POST['step'] === 'upload') {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        json_out(['ok' => false, 'error' => 'File tidak terunggah. Coba lagi.'], 400);
    }
    $f = $_FILES['file'];
    if ($f['size'] > 8 * 1024 * 1024) {
        json_out(['ok' => false, 'error' => 'Ukuran file maksimal 8 MB.'], 400);
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['xlsx', 'csv'], true)) {
        json_out(['ok' => false, 'error' => 'Format harus .xlsx atau .csv'], 400);
    }

    try {
        $rows = XlsxReader::readAny($f['tmp_name'], $ext);
    } catch (RuntimeException $e) {
        json_out(['ok' => false, 'error' => $e->getMessage()], 400);
    }

    if (count($rows) < 2) {
        json_out(['ok' => false, 'error' => 'File tidak berisi data (minimal baris header + 1 barang).'], 400);
    }

    $headers = [];
    foreach ($rows[0] as $i => $h) {
        $headers[$i] = trim((string)($h ?? ('Kolom ' . huruf_kolom($i))));
        if ($headers[$i] === '') {
            $headers[$i] = 'Kolom ' . huruf_kolom($i);
        }
    }

    $dataRows = array_slice($rows, 1);
    // buang baris tanpa teks sama sekali
    $dataRows = array_values(array_filter($dataRows, function ($r) {
        foreach ($r as $v) {
            if ($v !== null && trim((string)$v) !== '') {
                return true;
            }
        }
        return false;
    }));

    $token = bin2hex(random_bytes(8));
    $src = TMP_DIR . '/' . $token . '.src';
    if (!@move_uploaded_file($f['tmp_name'], $src)) {
        if (!@copy($f['tmp_name'], $src)) {
            json_out(['ok' => false, 'error' => 'Gagal menyimpan file sementara (cek izin folder exports/).'], 500);
        }
    }
    file_put_contents(TMP_DIR . '/' . $token . '.json', json_encode([
        'file'    => basename((string)$f['name']),
        'ext'     => $ext,
        'total'   => count($dataRows),
        'headers' => array_values($headers),
    ]));

    // bersihkan file sementara > 1 hari
    foreach (glob(TMP_DIR . '/*') as $old) {
        if (is_file($old) && filemtime($old) < time() - 86400) {
            @unlink($old);
        }
    }

    $kolom = [];
    foreach ($headers as $i => $h) {
        $kolom[] = ['idx' => $i, 'huruf' => huruf_kolom($i), 'label' => $h];
    }
    $contoh = array_slice($dataRows, 0, 5);

    json_out([
        'ok'     => true,
        'token'  => $token,
        'file'   => basename((string)$f['name']),
        'total'  => count($dataRows),
        'kolom'  => $kolom,
        'contoh' => $contoh,
        'guess'  => tebak_map($headers),
    ]);
}

/* ---------- Step: run (per bagian) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = body_json();
    if (($b['step'] ?? '') !== 'run') {
        json_out(['ok' => false, 'error' => 'Step tidak dikenal.'], 400);
    }

    $token = preg_replace('/[^a-f0-9]/', '', (string)($b['token'] ?? ''));
    $metaFile = TMP_DIR . '/' . $token . '.json';
    $srcFile = TMP_DIR . '/' . $token . '.src';
    if ($token === '' || !is_file($metaFile) || !is_file($srcFile)) {
        json_out(['ok' => false, 'error' => 'Sesi import tidak ditemukan. Ulangi dari awal.'], 400);
    }
    $meta = json_decode((string)file_get_contents($metaFile), true);
    if (!is_array($meta)) {
        json_out(['ok' => false, 'error' => 'Metadata import rusak. Ulangi dari awal.'], 400);
    }

    $map = isset($b['map']) && is_array($b['map']) ? $b['map'] : [];
    if (!isset($map['nama']) || $map['nama'] === null || (int)$map['nama'] < 0) {
        json_out(['ok' => false, 'error' => 'Kolom "Nama Barang" wajib dipetakan.'], 400);
    }
    $idxNama = (int)$map['nama'];
    $idxKat = isset($map['kategori']) && $map['kategori'] !== null ? (int)$map['kategori'] : null;
    $idxBarcode = isset($map['barcode']) && $map['barcode'] !== null ? (int)$map['barcode'] : null;
    $idxBeli = isset($map['harga_beli']) && $map['harga_beli'] !== null ? (int)$map['harga_beli'] : null;
    $idxJual = isset($map['harga_jual']) && $map['harga_jual'] !== null ? (int)$map['harga_jual'] : null;
    $idxStok = isset($map['stok']) && $map['stok'] !== null ? (int)$map['stok'] : null;
    $idxSatuan = isset($map['satuan']) && $map['satuan'] !== null ? (int)$map['satuan'] : null;

    $offset = max(0, (int)($b['offset'] ?? 0));
    $chunk = 25;

    try {
        $rows = XlsxReader::readAny($srcFile, (string)$meta['ext']);
    } catch (RuntimeException $e) {
        json_out(['ok' => false, 'error' => $e->getMessage()], 400);
    }
    $dataRows = array_slice($rows, 1);
    $total = (int)$meta['total'];
    $bagian = array_slice($dataRows, $offset, $chunk);

    $stCek = $pdo->prepare('SELECT id FROM kategori WHERE nama = ? LIMIT 1');
    $stInsKat = $pdo->prepare('INSERT INTO kategori (nama) VALUES (?)');
    $stCariNama = $pdo->prepare('SELECT id FROM produk WHERE LOWER(nama) = LOWER(?) AND aktif = 1 LIMIT 1');
    $stCariBarcode = $pdo->prepare('SELECT id FROM produk WHERE barcode = ? AND aktif = 1 LIMIT 1');
    $stCekBarcode = $pdo->prepare('SELECT id FROM produk WHERE barcode = ? AND id <> ? LIMIT 1');
    $stIns = $pdo->prepare('INSERT INTO produk (nama, kategori_id, satuan, barcode, harga_beli, harga_jual, stok, is_new) VALUES (?,?,?,?,?,?,?,1)');
    $stUpd = $pdo->prepare('UPDATE produk SET kategori_id = COALESCE(?, kategori_id), harga_beli = ?, harga_jual = ?, stok = ?, satuan = ?, barcode = COALESCE(?, barcode) WHERE id = ?');
    $stUpdBc = $pdo->prepare('UPDATE produk SET kategori_id = COALESCE(?, kategori_id), harga_beli = ?, harga_jual = ?, stok = ?, satuan = ?, barcode = ? WHERE id = ?');

    $baru = 0;
    $update = 0;
    $gagal = 0;

    $kategoriCache = [];

    foreach ($bagian as $row) {
        $nama = isset($row[$idxNama]) ? trim((string)$row[$idxNama]) : '';
        if ($nama === '' || $nama === '-' || strtolower($nama) === 'null') {
            $gagal++;
            continue;
        }

        $katNama = ($idxKat !== null && isset($row[$idxKat])) ? trim((string)$row[$idxKat]) : '';
        $barcode = ($idxBarcode !== null && isset($row[$idxBarcode])) ? trim((string)$row[$idxBarcode]) : '';
        if ($barcode === '' || $barcode === '-' || strtolower($barcode) === 'null') {
            $barcode = null;
        }
        $beli = ($idxBeli !== null && isset($row[$idxBeli])) ? parse_angka($row[$idxBeli]) : 0.0;
        $jual = ($idxJual !== null && isset($row[$idxJual])) ? parse_angka($row[$idxJual]) : 0.0;
        $stok = ($idxStok !== null && isset($row[$idxStok])) ? max(0, (int)round(parse_angka($row[$idxStok]))) : null;
        $satuan = ($idxSatuan !== null && isset($row[$idxSatuan]) && trim((string)$row[$idxSatuan]) !== '') ? trim((string)$row[$idxSatuan]) : 'pcs';

        // Kategori: cari / buat
        $katId = null;
        if ($katNama !== '') {
            $key = strtolower($katNama);
            if (isset($kategoriCache[$key])) {
                $katId = $kategoriCache[$key];
            } else {
                $stCek->execute([$katNama]);
                $ada = $stCek->fetch();
                if ($ada) {
                    $katId = (int)$ada['id'];
                } else {
                    $stInsKat->execute([$katNama]);
                    $katId = (int)$pdo->lastInsertId();
                }
                $kategoriCache[$key] = $katId;
            }
        }

        // Cari barang sasaran: lebih dulu lewat barcode, lalu nama
        $target = null;
        $matchViaBarcode = false;
        if ($barcode !== null) {
            $stCariBarcode->execute([$barcode]);
            $target = $stCariBarcode->fetch();
            $matchViaBarcode = (bool)$target;
        }
        if (!$target) {
            $stCariNama->execute([$nama]);
            $target = $stCariNama->fetch();
        }

        if ($target) {
            // Perbarui barang lama (stok diganti sesuai file bila kolom stok dipetakan)
            $targetId = (int)$target['id'];
            $stCari2 = $pdo->prepare('SELECT stok FROM produk WHERE id = ?');
            $stCari2->execute([$targetId]);
            $stokLama = (int)$stCari2->fetchColumn();
            $stokBaru = ($stok === null) ? $stokLama : $stok;
            if ($barcode !== null && !$matchViaBarcode) {
                // cocok lewat nama tapi barcode di file juga diisi:
                // simpan hanya bila barcode belum dipakai barang lain
                $stCekBarcode->execute([$barcode, $targetId]);
                if (!$stCekBarcode->fetch()) {
                    $stUpdBc->execute([$katId, $beli, $jual, $stokBaru, $satuan, $barcode, $targetId]);
                } else {
                    $stUpd->execute([$katId, $beli, $jual, $stokBaru, $satuan, null, $targetId]);
                }
            } else {
                $stUpd->execute([$katId, $beli, $jual, $stokBaru, $satuan, $barcode, $targetId]);
            }
            $update++;
        } else {
            // Barang baru: pastikan barcode belum dipakai agar tidak bentrok UNIQUE
            $bcSimpan = $barcode;
            if ($bcSimpan !== null) {
                $stCekBarcode->execute([$bcSimpan, 0]);
                if ($stCekBarcode->fetch()) {
                    $bcSimpan = null;
                }
            }
            $stIns->execute([$nama, $katId, $satuan, $bcSimpan, $beli, $jual, ($stok === null ? 0 : $stok)]);
            $baru++;
        }
    }

    $offset += count($bagian);
    $done = ($offset >= $total);

    if ($done) {
        $pdo->prepare('INSERT INTO import_log (nama_file, total_row, jumlah_baru, jumlah_update, jumlah_gagal) VALUES (?,?,?,?,?)')
            ->execute([(string)$meta['file'], $total, $baru, $update, $gagal]);
        @unlink($metaFile);
        @unlink($srcFile);
    } else {
        // simpan kumulatif agar ringkasan akhir lengkap
        $meta['kumulatif'] = [
            'baru'   => ($meta['kumulatif']['baru'] ?? 0) + $baru,
            'update' => ($meta['kumulatif']['update'] ?? 0) + $update,
            'gagal'  => ($meta['kumulatif']['gagal'] ?? 0) + $gagal,
        ];
        file_put_contents($metaFile, json_encode($meta));
    }

    json_out([
        'ok'        => true,
        'processed' => count($bagian),
        'offset'    => $offset,
        'total'     => $total,
        'done'      => $done,
        'progress'  => $total > 0 ? min(100, round($offset / $total * 100)) : 100,
        'baru'      => $done ? (($meta['kumulatif']['baru'] ?? 0) + $baru) : (($meta['kumulatif']['baru'] ?? 0) + $baru),
        'update'    => ($meta['kumulatif']['update'] ?? 0) + $update,
        'gagal'     => ($meta['kumulatif']['gagal'] ?? 0) + $gagal,
    ]);
}

json_out(['ok' => false, 'error' => 'Permintaan tidak valid.'], 400);
