<?php
/**
 * API: Laporan
 *  - GET ?periode=hari|minggu|bulan  -> kartu ringkasan, grafik 7 hari, terlaris, transaksi terakhir
 *  - GET ?export=xlsx&periode=...    -> unduh laporan .xlsx
 */
require_once __DIR__ . '/../config.php';
require_once BASE_PATH . '/includes/laporan_data.php';
require_once BASE_PATH . '/lib/xlsx_writer.php';

$pdo = db();
$d = laporan_data($pdo, $_GET['periode'] ?? 'hari');
$periode = $d['periode'];
$label = $d['label'];
$jumlah = $d['ringkasan']['jumlah'];
$omzet = $d['ringkasan']['omzet'];
$laba = $d['ringkasan']['laba'];
$produkTerjual = $d['ringkasan']['produk'];
$ratarata = $d['ringkasan']['rata'];

/* ---------- Ekspor XLSX ---------- */
if (isset($_GET['export']) && $_GET['export'] === 'xlsx') {
    $rows = array_map(function ($row) {
        return [
            date('d/m/Y H:i', strtotime($row['tanggal'])),
            $row['kode'],
            $row['metode'],
            $row['kasir'],
            $row['subtotal'],
            $row['diskon'],
            $row['total'],
            $row['laba'],
        ];
    }, $d['semua']);

    $sheets = [
        [
            'nama'   => 'Ringkasan',
            'widths' => [26, 22],
            'rows'   => [
                ['Laporan Penjualan', ''],
                ['Toko', get_setting('toko_nama')],
                ['Periode', $label],
                ['Omzet', $omzet],
                ['Jumlah Transaksi', $jumlah],
                ['Laba', $laba],
                ['Produk Terjual', $produkTerjual],
                ['Rata-rata per Transaksi', $ratarata],
                ['Diekspor', date('d/m/Y H:i')],
            ],
        ],
        [
            'nama'   => 'Transaksi',
            'widths' => [16, 20, 12, 14, 14, 12, 14, 14],
            'rows'   => array_merge(
                [['Tanggal', 'Kode', 'Metode', 'Kasir', 'Subtotal', 'Diskon', 'Total', 'Laba']],
                $rows
            ),
        ],
        [
            'nama'   => 'Produk Terlaris',
            'widths' => [34, 14, 16],
            'rows'   => array_merge(
                [['Produk', 'Qty Terjual', 'Omzet']],
                array_map(function ($t) {
                    return [$t['nama'], $t['qty'], $t['omzet']];
                }, $d['top'])
            ),
        ],
    ];

    XlsxWriter::download('laporan-' . $periode . '-' . date('Ymd-His') . '.xlsx', $sheets);
}

json_out([
    'ok'       => true,
    'periode'  => $periode,
    'label'    => $label,
    'ringkasan' => $d['ringkasan'],
    'chart'    => $d['chart'],
    'top'      => $d['top'],
    'terakhir' => $d['terakhir'],
]);
