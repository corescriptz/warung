<?php
/**
 * API: Pengaturan
 *  - GET            -> semua pengaturan + info import terakhir
 *  - POST           -> simpan pengaturan
 *  - GET ?backup=1  -> buat & unduh backup .sql
 */
require_once __DIR__ . '/../config.php';
require_once BASE_PATH . '/lib/backup.php';

ensure_export_dirs();
$pdo = db();

/* ---------- Backup ---------- */
if (isset($_GET['backup'])) {
    $file = EXPORT_DIR . '/' . backup_filename('backup');
    create_backup($file);
    set_setting('backup_terakhir', date('Y-m-d H:i:s'));

    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    header('Content-Length: ' . (string)filesize($file));
    readfile($file);
    exit;
}

/* ---------- Simpan pengaturan ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = body_json();
    $boleh = ['toko_nama', 'toko_alamat', 'toko_telp', 'struk_footer', 'kasir_nama', 'printer_nama', 'printer_lebar', 'auto_backup'];
    foreach ($boleh as $k) {
        if (array_key_exists($k, $b)) {
            $v = is_scalar($b[$k]) ? (string)$b[$k] : '';
            if ($k === 'printer_lebar' && !in_array($v, ['58', '80'], true)) {
                $v = '58';
            }
            if ($k === 'auto_backup') {
                $v = ($v === '1' || $v === 'true') ? '1' : '0';
            }
            set_setting($k, trim($v));
        }
    }
    json_out(['ok' => true, 'saved' => true, 'backup_terakhir' => get_setting('backup_terakhir')]);
}

/* ---------- Ambil pengaturan ---------- */
$s = all_settings();

$lastImport = null;
try {
    $r = $pdo->query('SELECT nama_file, total_row, jumlah_baru, jumlah_update, jumlah_gagal, dibuat_pada FROM import_log ORDER BY id DESC LIMIT 1')->fetch();
    if ($r) {
        $lastImport = [
            'file'   => $r['nama_file'],
            'total'  => (int)$r['total_row'],
            'baru'   => (int)$r['jumlah_baru'],
            'update' => (int)$r['jumlah_update'],
            'gagal'  => (int)$r['jumlah_gagal'],
            'waktu'  => $r['dibuat_pada'],
        ];
    }
} catch (Throwable $e) {
}

// Info backup otomatis hari ini
$autoHariIni = file_exists(EXPORT_DIR . '/auto-backup-' . date('Ymd') . '.sql');

json_out([
    'ok'   => true,
    'data' => [
        'toko_nama'       => $s['toko_nama'],
        'toko_alamat'     => $s['toko_alamat'],
        'toko_telp'       => $s['toko_telp'],
        'struk_footer'    => $s['struk_footer'],
        'kasir_nama'      => $s['kasir_nama'],
        'printer_nama'    => $s['printer_nama'],
        'printer_lebar'   => $s['printer_lebar'],
        'auto_backup'     => $s['auto_backup'],
        'backup_terakhir' => $s['backup_terakhir'],
        'auto_backup_hari_ini' => $autoHariIni,
    ],
    'last_import' => $lastImport,
]);
