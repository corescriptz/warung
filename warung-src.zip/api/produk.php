<?php
/**
 * API: Produk & kategori
 *  - GET               -> daftar produk + kategori (+ info toko/kasir)
 *  - POST aksi=simpan  -> tambah / ubah produk (manajemen produk manual)
 *  - POST aksi=hapus   -> hapus produk (nonaktifkan, riwayat lama tetap utuh)
 */
require_once __DIR__ . '/../config.php';

$pdo = db();

/* ---------- POST: simpan / hapus ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = body_json();
    $aksi = $b['aksi'] ?? '';

    if ($aksi === 'hapus') {
        $id = (int)($b['id'] ?? 0);
        if ($id <= 0) {
            json_out(['ok' => false, 'error' => 'Produk tidak valid.'], 400);
        }
        // Nonaktifkan + lepaskan barcode agar bisa dipakai barang lain
        $st = $pdo->prepare('UPDATE produk SET aktif = 0, barcode = NULL WHERE id = ?');
        $st->execute([$id]);
        json_out(['ok' => true]);
    }

    if ($aksi === 'simpan') {
        $id = (int)($b['id'] ?? 0);

        $nama = trim((string)($b['nama'] ?? ''));
        if ($nama === '') {
            json_out(['ok' => false, 'error' => 'Nama barang wajib diisi.'], 400);
        }
        if (mb_strlen($nama) > 150) {
            json_out(['ok' => false, 'error' => 'Nama barang maksimal 150 karakter.'], 400);
        }

        $satuan = trim((string)($b['satuan'] ?? 'pcs'));
        if ($satuan === '') {
            $satuan = 'pcs';
        }
        if (mb_strlen($satuan) > 20) {
            json_out(['ok' => false, 'error' => 'Satuan maksimal 20 karakter.'], 400);
        }

        $beli = (float)($b['harga_beli'] ?? 0);
        $jual = (float)($b['harga_jual'] ?? 0);
        $stok = max(0, (int)($b['stok'] ?? 0));
        $stokMin = max(0, (int)($b['stok_minimal'] ?? 5));
        if ($beli < 0 || $jual < 0) {
            json_out(['ok' => false, 'error' => 'Harga tidak boleh minus.'], 400);
        }
        if ($jual <= 0) {
            json_out(['ok' => false, 'error' => 'Harga jual harus lebih dari 0.'], 400);
        }

        // Barcode: kosong -> NULL. Wajib unik antar barang.
        $barcode = trim((string)($b['barcode'] ?? ''));
        if ($barcode === '') {
            $barcode = null;
        } elseif (mb_strlen($barcode) > 64) {
            json_out(['ok' => false, 'error' => 'Barcode maksimal 64 karakter.'], 400);
        } else {
            $st = $pdo->prepare('SELECT id, nama FROM produk WHERE barcode = ? AND aktif = 1 AND id <> ? LIMIT 1');
            $st->execute([$barcode, $id]);
            $dupe = $st->fetch();
            if ($dupe) {
                json_out(['ok' => false, 'error' => 'Barcode sudah dipakai barang "' . $dupe['nama'] . '".'], 400);
            }
        }

        // Kategori: cari, buat bila belum ada. Kosong -> NULL (Lainnya).
        $katNama = trim((string)($b['kategori'] ?? ''));
        $katId = null;
        if ($katNama !== '') {
            if (mb_strlen($katNama) > 60) {
                json_out(['ok' => false, 'error' => 'Nama kategori maksimal 60 karakter.'], 400);
            }
            $st = $pdo->prepare('SELECT id FROM kategori WHERE nama = ? LIMIT 1');
            $st->execute([$katNama]);
            $katId = $st->fetchColumn();
            if ($katId === false) {
                $pdo->prepare('INSERT INTO kategori (nama) VALUES (?)')->execute([$katNama]);
                $katId = (int)$pdo->lastInsertId();
            }
            $katId = (int)$katId;
        }

        if ($id > 0) {
            $st = $pdo->prepare('SELECT id FROM produk WHERE id = ? AND aktif = 1');
            $st->execute([$id]);
            if (!$st->fetch()) {
                json_out(['ok' => false, 'error' => 'Barang tidak ditemukan.'], 404);
            }
            try {
                $pdo->prepare('UPDATE produk SET nama = ?, kategori_id = ?, satuan = ?, barcode = ?, harga_beli = ?, harga_jual = ?, stok = ?, stok_minimal = ? WHERE id = ?')
                    ->execute([$nama, $katId, $satuan, $barcode, $beli, $jual, $stok, $stokMin, $id]);
            } catch (PDOException $e) {
                json_out(['ok' => false, 'error' => 'Barcode sudah dipakai barang lain.'], 400);
            }
        } else {
            try {
                $pdo->prepare('INSERT INTO produk (nama, kategori_id, satuan, barcode, harga_beli, harga_jual, stok, stok_minimal, is_new) VALUES (?,?,?,?,?,?,?,?,1)')
                    ->execute([$nama, $katId, $satuan, $barcode, $beli, $jual, $stok, $stokMin]);
            } catch (PDOException $e) {
                json_out(['ok' => false, 'error' => 'Barcode sudah dipakai barang lain.'], 400);
            }
            $id = (int)$pdo->lastInsertId();
        }

        json_out(['ok' => true, 'id' => $id]);
    }

    json_out(['ok' => false, 'error' => 'Aksi tidak dikenal.'], 400);
}

/* ---------- GET ---------- */

// Daftar kategori
$kategori = [];
foreach ($pdo->query('SELECT id, nama FROM kategori ORDER BY nama') as $r) {
    $kategori[] = ['id' => (int)$r['id'], 'nama' => $r['nama']];
}

// Daftar produk aktif (badge "Baru" tampil 7 hari sejak dibuat)
$produk = [];
$sql = "SELECT p.id, p.nama, p.kategori_id, k.nama AS kategori, p.satuan, p.barcode,
               p.harga_beli, p.harga_jual, p.stok, p.stok_minimal,
               (p.is_new = 1 AND p.dibuat_pada >= NOW() - INTERVAL 7 DAY) AS baru
        FROM produk p
        LEFT JOIN kategori k ON k.id = p.kategori_id
        WHERE p.aktif = 1
        ORDER BY p.nama ASC";
foreach ($pdo->query($sql) as $r) {
    $produk[] = [
        'id'          => (int)$r['id'],
        'nama'        => $r['nama'],
        'kategori_id' => $r['kategori_id'] === null ? null : (int)$r['kategori_id'],
        'kategori'    => $r['kategori'] ?: 'Lainnya',
        'satuan'      => $r['satuan'],
        'barcode'     => $r['barcode'] ?: '',
        'harga_beli'  => (float)$r['harga_beli'],
        'harga_jual'  => (float)$r['harga_jual'],
        'stok'        => (int)$r['stok'],
        'stok_minimal'=> (int)$r['stok_minimal'],
        'baru'        => (int)$r['baru'] === 1,
    ];
}

json_out([
    'ok'       => true,
    'kategori' => $kategori,
    'produk'   => $produk,
    'toko'     => ['nama' => get_setting('toko_nama')],
    'kasir'    => get_setting('kasir_nama'),
    'tanggal'  => tanggal_indo(date('Y-m-d H:i:s')),
]);
