<?php
/**
 * API: Transaksi
 *  - POST : simpan transaksi baru (checkout) -> balas payload struk
 *  - GET ?id= : ambil payload struk transaksi lama
 */
require_once __DIR__ . '/../config.php';

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = body_json();

    $itemsIn = isset($b['items']) && is_array($b['items']) ? $b['items'] : [];
    if (!$itemsIn) {
        json_out(['ok' => false, 'error' => 'Keranjang kosong.'], 400);
    }

    $metode = in_array($b['metode'] ?? 'Tunai', ['Tunai', 'QRIS', 'Transfer'], true) ? $b['metode'] : 'Tunai';
    $diskon = max(0.0, (float)($b['diskon'] ?? 0));
    $bayarIn = max(0.0, (float)($b['bayar'] ?? 0));
    $kasir = trim((string)($b['kasir'] ?? 'Kasir'));
    if ($kasir === '') {
        $kasir = 'Kasir';
    }

    // Kumpulkan id & qty valid
    $req = [];
    foreach ($itemsIn as $it) {
        $id = (int)($it['id'] ?? 0);
        $qty = (int)($it['qty'] ?? 0);
        if ($id > 0 && $qty > 0) {
            if (isset($req[$id])) {
                $req[$id] += $qty;
            } else {
                $req[$id] = $qty;
            }
        }
    }
    if (!$req) {
        json_out(['ok' => false, 'error' => 'Item keranjang tidak valid.'], 400);
    }

    // Ambil produk dari database (harga jangan percaya dari client)
    $ids = array_keys($req);
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT id, nama, satuan, harga_beli, harga_jual, stok FROM produk WHERE id IN ($in) AND aktif = 1");
    $st->execute($ids);
    $prod = [];
    foreach ($st->fetchAll() as $r) {
        $prod[(int)$r['id']] = $r;
    }

    // Validasi stok & hitung
    $subtotal = 0.0;
    $laba = 0.0;
    $detail = [];
    foreach ($req as $id => $qty) {
        if (!isset($prod[$id])) {
            json_out(['ok' => false, 'error' => 'Ada barang yang sudah tidak tersedia. Muat ulang halaman.'], 400);
        }
        $p = $prod[$id];
        if ((int)$p['stok'] < $qty) {
            json_out(['ok' => false, 'error' => 'Stok "' . $p['nama'] . '" tidak cukup (tersisa ' . (int)$p['stok'] . ').'], 400);
        }
        $sub = (float)$p['harga_jual'] * $qty;
        $lb = ((float)$p['harga_jual'] - (float)$p['harga_beli']) * $qty;
        $subtotal += $sub;
        $laba += $lb;
        $detail[] = [
            'produk_id' => (int)$p['id'],
            'nama'      => $p['nama'],
            'satuan'    => $p['satuan'],
            'beli'      => (float)$p['harga_beli'],
            'jual'      => (float)$p['harga_jual'],
            'qty'       => $qty,
            'sub'       => $sub,
            'laba'      => $lb,
        ];
    }

    if ($diskon > $subtotal) {
        $diskon = $subtotal;
    }
    $total = $subtotal - $diskon;

    if ($metode === 'Tunai') {
        if ($bayarIn < $total) {
            json_out(['ok' => false, 'error' => 'Uang bayar kurang dari total.'], 400);
        }
        $bayar = $bayarIn;
        $kembalian = $bayar - $total;
    } else {
        $bayar = $total;
        $kembalian = 0.0;
    }

    // Simpan dalam satu transaksi database
    try {
        $pdo->beginTransaction();

        $kodeSementara = 'TMP-' . uniqid();
        $st = $pdo->prepare('INSERT INTO transaksi (kode, tanggal, subtotal, diskon, total, bayar, kembalian, metode, laba, kasir) VALUES (?,?,?,?,?,?,?,?,?,?)');
        $st->execute([
            $kodeSementara, date('Y-m-d H:i:s'), $subtotal, $diskon, $total,
            $bayar, $kembalian, $metode, $laba, $kasir,
        ]);
        $txId = (int)$pdo->lastInsertId();
        $kode = 'TRX-' . date('Ymd') . '-' . str_pad((string)$txId, 4, '0', STR_PAD_LEFT);
        $pdo->prepare('UPDATE transaksi SET kode = ? WHERE id = ?')->execute([$kode, $txId]);

        $stD = $pdo->prepare('INSERT INTO transaksi_detail (transaksi_id, produk_id, nama_produk, satuan, harga_beli, harga_jual, qty, subtotal, laba) VALUES (?,?,?,?,?,?,?,?,?)');
        $stU = $pdo->prepare('UPDATE produk SET stok = stok - ? WHERE id = ? AND stok >= ?');
        foreach ($detail as $d) {
            $stD->execute([$txId, $d['produk_id'], $d['nama'], $d['satuan'], $d['beli'], $d['jual'], $d['qty'], $d['sub'], $d['laba']]);
            $stU->execute([$d['qty'], $d['produk_id'], $d['qty']]);
            if ($stU->rowCount() < 1) {
                // Stok berubah di tengah jalan (kasir lain baru saja menjual) -> batalkan semua
                throw new RuntimeException('Stok "' . $d['nama'] . '" baru saja berubah. Muat ulang halaman lalu coba lagi.');
            }
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        json_out(['ok' => false, 'error' => 'Gagal menyimpan transaksi: ' . $e->getMessage()], 500);
    }

    json_out(['ok' => true, 'transaksi' => struk_payload($pdo, $txId)]);
}

/* ---------- GET ---------- */
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    json_out(['ok' => false, 'error' => 'Parameter id wajib.'], 400);
}
$payload = struk_payload($pdo, $id);
if (!$payload) {
    json_out(['ok' => false, 'error' => 'Transaksi tidak ditemukan.'], 404);
}
json_out(['ok' => true, 'transaksi' => $payload]);
