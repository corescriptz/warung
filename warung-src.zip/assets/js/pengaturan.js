/* ============================================================
   HALAMAN PENGATURAN — profil, printer, backup, import Excel
   ============================================================ */
'use strict';

var imp = { token: null, total: 0, kolom: [], contoh: [], map: {} };

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('headDate').textContent = tanggalIndo();

    /* ---------- Simpan pengaturan ---------- */
    document.getElementById('btnSave').addEventListener('click', simpanPengaturan);

    /* ---------- Segmented lebar kertas ---------- */
    initSeg('#segLebar');

    /* ---------- Tes cetak ---------- */
    document.getElementById('btnTesCetak').addEventListener('click', tesCetak);

    /* ---------- Backup ---------- */
    document.getElementById('btnBackupNow').addEventListener('click', backupSekarang);

    /* ---------- Import ---------- */
    document.getElementById('btnOpenImport').addEventListener('click', function () {
        document.getElementById('importOverlay').classList.add('show');
        impStep(1);
    });
    document.getElementById('importClose').addEventListener('click', tutupImport);
    document.getElementById('dropzone').addEventListener('click', function () {
        document.getElementById('importFile').click();
    });
    document.getElementById('importFile').addEventListener('change', unggahFile);
    document.getElementById('btnStartImport').addEventListener('click', mulaiImport);
    document.getElementById('btnGoTransaksi').addEventListener('click', function () {
        window.location.href = 'index.php';
    });
    document.getElementById('btnImportDone').addEventListener('click', tutupImport);
});

/* ---------- Simpan ---------- */
async function simpanPengaturan() {
    var btn = document.getElementById('btnSave');
    btn.disabled = true;
    try {
        var payload = {
            toko_nama: val('tokoNama'),
            toko_alamat: val('tokoAlamat'),
            toko_telp: val('tokoTelp'),
            struk_footer: val('strukFooter'),
            kasir_nama: val('kasirNama') || 'Kasir',
            printer_nama: val('printerNama'),
            printer_lebar: segVal('#segLebar') || '58',
            auto_backup: document.getElementById('autoBackup').checked ? '1' : '0'
        };
        var j = await postJson('api/pengaturan.php', payload);
        document.getElementById('lastBackup').textContent = j.backup_terakhir
            ? fmtWaktu(j.backup_terakhir) : 'Belum pernah';
        toast('Pengaturan tersimpan');
    } catch (e) {
        toast(e.message, 'err');
    }
    btn.disabled = false;
}
function val(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
function segVal(sel) { var b = document.querySelector(sel + ' button.on'); return b ? b.getAttribute('data-v') : null; }
function fmtWaktu(s) {
    var d = new Date(String(s).replace(' ', 'T'));
    if (isNaN(d)) return s;
    return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear()
        + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

/* ---------- Tes cetak struk ---------- */
function tesCetak() {
    var t = {
        kode: 'TEST-CETAK',
        tanggal: new Date().toISOString().slice(0, 19).replace('T', ' '),
        kasir: 'Tes Printer',
        metode: 'Tunai',
        items: [
            { nama: 'Contoh Barang A', satuan: 'pcs', qty: 1, harga: 15000, subtotal: 15000 },
            { nama: 'Contoh Barang B', satuan: 'pcs', qty: 2, harga: 5000, subtotal: 10000 }
        ],
        subtotal: 25000, diskon: 0, total: 25000, bayar: 50000, kembalian: 25000,
        toko: {
            nama: val('tokoNama') || 'Toko Saya',
            alamat: val('tokoAlamat'),
            telp: val('tokoTelp'),
            footer: val('strukFooter')
        }
    };
    cetakStruk(t);
    toast('Struk tes dikirim ke printer (dialog cetak)');
}

/* ---------- Backup sekarang ---------- */
async function backupSekarang() {
    try {
        toast('Membuat backup...');
        var res = await fetch('api/pengaturan.php?backup=1');
        if (!res.ok) throw new Error('Backup gagal (' + res.status + ')');
        var blob = await res.blob();
        var cd = res.headers.get('content-disposition') || '';
        var m = cd.match(/filename="?([^";]+)"?/);
        var nama = m ? m[1] : ('backup-' + Date.now() + '.sql');
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = nama;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);

        var j = await api('api/pengaturan.php');
        document.getElementById('lastBackup').textContent = j.data.backup_terakhir
            ? fmtWaktu(j.data.backup_terakhir) : 'Belum pernah';
        toast('Backup berhasil: ' + nama);
    } catch (e) {
        toast(e.message, 'err');
    }
}

/* ============================================================
   IMPORT EXCEL — 4 langkah
   ============================================================ */
function impStep(n) {
    [1, 2, 3, 4].forEach(function (i) {
        document.getElementById('impStep' + i).hidden = (i !== n);
    });
    var dots = document.querySelectorAll('#stepper .step-dot');
    dots.forEach(function (d, i) { d.classList.toggle('on', i < n); });
}

function tutupImport() {
    document.getElementById('importOverlay').classList.remove('show');
    document.getElementById('importFile').value = '';
    imp = { token: null, total: 0, kolom: [], contoh: [], map: {} };
}

/* ---------- Langkah 1 -> 2 ---------- */
async function unggahFile(ev) {
    var file = ev.target.files[0];
    if (!file) return;
    var fd = new FormData();
    fd.append('file', file);
    fd.append('step', 'upload');
    toast('Membaca file...');
    try {
        var j = await api('api/import.php', { method: 'POST', body: fd });
        imp.token = j.token;
        imp.total = j.total;
        imp.kolom = j.kolom;
        imp.contoh = j.contoh;
        imp.map = j.guess || {};
        document.getElementById('impFileLabel').innerHTML =
            '<b>' + esc(j.file) + '</b> &middot; ' + j.total + ' barang terdeteksi';
        renderMapping();
        impStep(2);
        toast(j.total + ' barang siap diimport');
    } catch (e) {
        toast(e.message, 'err');
        ev.target.value = '';
    }
}

var FIELDS = [
    { key: 'nama',       label: 'Nama Barang', req: true },
    { key: 'barcode',    label: 'Barcode',     req: false },
    { key: 'kategori',   label: 'Kategori',    req: false },
    { key: 'harga_beli', label: 'Harga Beli',  req: false },
    { key: 'harga_jual', label: 'Harga Jual',  req: false },
    { key: 'stok',       label: 'Stok',        req: false },
    { key: 'satuan',     label: 'Satuan',      req: false }
];

function renderMapping() {
    var box = document.getElementById('mapList');
    var html = '';
    FIELDS.forEach(function (f) {
        var cur = (imp.map[f.key] === undefined || imp.map[f.key] === null) ? '' : String(imp.map[f.key]);
        html += '<div class="map-row"><label>' + f.label + (f.req ? ' <span class="req">*</span>' : '') + '</label>'
            + '<select data-field="' + f.key + '">'
            + '<option value="">— Lewati —</option>'
            + imp.kolom.map(function (k) {
                var v = String(k.idx);
                return '<option value="' + v + '"' + (cur === v ? ' selected' : '') + '>'
                    + k.huruf + ' &middot; ' + esc(k.label) + '</option>';
            }).join('')
            + '</select></div>';
    });
    box.innerHTML = html;
    box.addEventListener('change', function () { renderPreview(); });
    renderPreview();
}

function renderPreview() {
    imp.kolom.forEach(function (k) {
        var sel = document.querySelector('#mapList select[data-field="' + k.idx + '"]');
        if (sel) imp.map[sel.getAttribute('data-field')] = sel.value === '' ? null : Number(sel.value);
    });
    // Nama wajib: kalau kosong pakai kolom pertama
    if (imp.map.nama === null || imp.map.nama === undefined) {
        imp.map.nama = 0;
        var s = document.querySelector('#mapList select[data-field="nama"]');
        if (s) s.value = '0';
    }

    var head = '<tr><th>#</th>' + FIELDS.map(function (f) {
        var idx = imp.map[f.key];
        return '<th>' + f.label + (idx === null || idx === undefined ? ' <span style="color:var(--txt3)">(kosong)</span>' : ' &middot; ' + kolHuruf(idx)) + '</th>';
    }).join('') + '</tr>';

    var body = imp.contoh.map(function (row, i) {
        var tds = FIELDS.map(function (f) {
            var idx = imp.map[f.key];
            var v = (idx === null || idx === undefined || row[idx] === undefined) ? '' : row[idx];
            return '<td' + (v !== '' ? ' class="mapped"' : '') + '>' + esc(v) + '</td>';
        });
        return '<tr><td>' + (i + 1) + '</td>' + tds.join('') + '</tr>';
    }).join('');

    document.getElementById('previewTable').innerHTML = head + body;
}

function kolHuruf(i) {
    var s = '', n = Number(i) + 1;
    while (n > 0) { var m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
    return s;
}

/* ---------- Langkah 2 -> 3 -> 4 ---------- */
async function mulaiImport() {
    if (imp.map.nama === null || imp.map.nama === undefined) {
        toast('Petakan kolom Nama Barang terlebih dahulu', 'err');
        return;
    }
    impStep(3);
    setRing(0, '0/' + imp.total);
    document.getElementById('impStatus').textContent = 'Mengimpor barang...';

    var offset = 0;
    var akhir = { baru: 0, update: 0, gagal: 0 };
    try {
        while (true) {
            var j = await postJson('api/import.php', {
                step: 'run',
                token: imp.token,
                map: imp.map,
                offset: offset
            });
            offset = j.offset;
            akhir.baru = j.baru;
            akhir.update = j.update;
            akhir.gagal = j.gagal;
            setRing(j.progress, offset + '/' + imp.total);
            if (j.done || j.processed === 0) break;
        }
        document.getElementById('hasilBaru').textContent = akhir.baru;
        document.getElementById('hasilUpdate').textContent = akhir.update;
        document.getElementById('hasilGagal').textContent = akhir.gagal;
        document.getElementById('impStatus').textContent = 'Selesai';
        setTimeout(function () { impStep(4); }, 420);
    } catch (e) {
        document.getElementById('impStatus').textContent = 'Gagal: ' + e.message;
        toast(e.message, 'err');
    }
}

function setRing(pct, info) {
    pct = Math.max(0, Math.min(100, Number(pct) || 0));
    var fg = document.getElementById('ringFg');
    var C = 2 * Math.PI * 52; // r=52
    fg.style.strokeDashoffset = String(C * (1 - pct / 100));
    document.getElementById('ringPct').textContent = Math.round(pct) + '%';
    document.getElementById('ringInfo').textContent = info || '';
}
