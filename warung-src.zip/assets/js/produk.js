/* ============================================================
   HALAMAN PRODUK — manajemen barang manual (CRUD)
   ============================================================ */
'use strict';

var pstate = {
    produk: [],
    kategori: [],
    filterK: 'all',
    lowOnly: false,
    q: '',
    editId: 0      // 0 = tambah baru
};

var lstate = { q: '', ukuran: 'thermal58', copy: 2, pilih: {} };

var pel = {};

document.addEventListener('DOMContentLoaded', initProduk);

async function initProduk() {
    pel = {
        stat: document.getElementById('prodStat'),
        search: document.getElementById('searchInput'),
        searchClear: document.getElementById('searchClear'),
        chips: document.getElementById('chips'),
        list: document.getElementById('plist'),
        empty: document.getElementById('emptyState'),
        btnTambah: document.getElementById('btnTambah'),
        btnEmptyTambah: document.getElementById('btnEmptyTambah'),
        sheetForm: document.getElementById('sheetForm'),
        formJudul: document.getElementById('formJudul'),
        katList: document.getElementById('katList'),
        fNama: document.getElementById('fNama'),
        fKategori: document.getElementById('fKategori'),
        fBarcode: document.getElementById('fBarcode'),
        fBeli: document.getElementById('fBeli'),
        fJual: document.getElementById('fJual'),
        fStok: document.getElementById('fStok'),
        fStokMin: document.getElementById('fStokMin'),
        fSatuan: document.getElementById('fSatuan'),
        formInfo: document.getElementById('formInfo'),
        btnSimpan: document.getElementById('btnSimpan'),
        btnHapus: document.getElementById('btnHapus'),
        alertHapus: document.getElementById('alertHapus'),
        btnHapusYa: document.getElementById('btnHapusYa'),
        btnAutoBc: document.getElementById('btnAutoBc'),
        // Cetak label
        btnLabel: document.getElementById('btnLabel'),
        lblSearch: document.getElementById('lblSearch'),
        lblSemua: document.getElementById('lblSemua'),
        lblTersimpan: document.getElementById('lblTersimpan'),
        lblList: document.getElementById('lblList'),
        optUkuran: document.getElementById('optUkuran'),
        lblMinus: document.getElementById('lblMinus'),
        lblPlus: document.getElementById('lblPlus'),
        lblCopy: document.getElementById('lblCopy'),
        lblTotal: document.getElementById('lblTotal'),
        btnCetakLabel: document.getElementById('btnCetakLabel')
    };

    pel.search.addEventListener('input', function () {
        pstate.q = pel.search.value.trim().toLowerCase();
        pel.searchClear.classList.toggle('show', pstate.q.length > 0);
        renderList();
    });
    pel.searchClear.addEventListener('click', function () {
        pel.search.value = '';
        pstate.q = '';
        pel.searchClear.classList.remove('show');
        renderList();
        pel.search.focus();
    });

    pel.btnTambah.addEventListener('click', function () { bukaForm(0); });
    pel.btnEmptyTambah.addEventListener('click', function () { bukaForm(0); });
    pel.btnSimpan.addEventListener('click', simpan);
    pel.btnHapus.addEventListener('click', function () {
        var p = cariProduk(pstate.editId);
        if (!p) return;
        pel.alertHapus.classList.add('show');
        haptic(10);
    });
    pel.alertHapus.addEventListener('click', function (ev) {
        if (ev.target.closest('[data-alert-close]')) {
            pel.alertHapus.classList.remove('show');
        }
    });
    pel.btnHapusYa.addEventListener('click', hapus);

    // Scanner USB menembak barcode + Enter di kolom barcode -> lompat ke harga beli
    pel.fBarcode.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') {
            ev.preventDefault();
            pel.fBeli.focus();
        }
    });

    // Tombol Auto: isi kode internal unik (untuk barang curah tanpa barcode pabrik)
    pel.btnAutoBc.addEventListener('click', function () {
        var terpakai = {};
        pstate.produk.forEach(function (p) { if (p.barcode) terpakai[p.barcode] = true; });
        var d = new Date();
        var pref = 'WK' + String(d.getFullYear()).slice(2)
            + String(d.getMonth() + 1).padStart(2, '0')
            + String(d.getDate()).padStart(2, '0') + '-';
        var kode;
        do {
            kode = pref + String(Math.floor(1000 + Math.random() * 9000));
        } while (terpakai[kode]);
        pel.fBarcode.value = kode;
        haptic(8);
        toast('Kode internal ' + kode + ' dibuat');
    });

    /* ---------- Cetak label barcode ---------- */
    pel.btnLabel.addEventListener('click', bukaSheetLabel);
    pel.lblSearch.addEventListener('input', function () {
        lstate.q = pel.lblSearch.value.trim().toLowerCase();
        renderLblList();
    });
    pel.lblSemua.addEventListener('click', pilihSemua);
    pel.optUkuran.addEventListener('click', function (ev) {
        var b = ev.target.closest('.opt');
        if (!b) return;
        lstate.ukuran = b.getAttribute('data-u');
        pel.optUkuran.querySelectorAll('.opt').forEach(function (o) { o.classList.toggle('on', o === b); });
        haptic(6);
    });
    pel.lblMinus.addEventListener('click', function () { setCopy(lstate.copy - 1); });
    pel.lblPlus.addEventListener('click', function () { setCopy(lstate.copy + 1); });
    pel.lblList.addEventListener('click', function (ev) {
        var row = ev.target.closest('.lrow');
        if (!row || row.classList.contains('dis')) return;
        var id = Number(row.getAttribute('data-id'));
        if (lstate.pilih[id]) { delete lstate.pilih[id]; } else { lstate.pilih[id] = true; }
        row.classList.toggle('on', !!lstate.pilih[id]);
        haptic(6);
        updateLblInfo();
    });
    pel.btnCetakLabel.addEventListener('click', cetakLabelSubmit);

    [pel.fBeli, pel.fJual, pel.fStok, pel.fStokMin].forEach(function (inp) {
        inp.addEventListener('input', function () {
            inp.value = inp.value.replace(/[^\d]/g, '');
        });
    });

    await muat();
}

/* ---------- Data ---------- */
async function muat() {
    pel.list.innerHTML = '<div class="skel"></div><div class="skel"></div><div class="skel"></div>';
    try {
        var j = await api('api/produk.php');
        pstate.produk = j.produk;
        pstate.kategori = j.kategori;
        renderChips();
        renderList();
    } catch (e) {
        pel.list.innerHTML = '';
        toast(e.message, 'err');
    }
}

function cariProduk(id) {
    return pstate.produk.filter(function (p) { return p.id === id; })[0] || null;
}

/* ---------- Chips kategori ---------- */
function renderChips() {
    var html = '<button class="chip' + (pstate.filterK === 'all' ? ' on' : '') + '" data-k="all" style="--h:250">Semua</button>';
    pstate.kategori.forEach(function (k) {
        html += '<button class="chip' + (String(pstate.filterK) === String(k.id) ? ' on' : '') + '" data-k="' + k.id + '" style="--h:' + catHue(k.nama) + '"><i class="cd"></i>' + esc(k.nama) + '</button>';
    });
    html += '<button class="chip chip-plus" data-k="__new">+ Barang</button>';
    pel.chips.innerHTML = html;
    pel.chips.onclick = function (ev) {
        var b = ev.target.closest('.chip');
        if (!b) return;
        var k = b.getAttribute('data-k');
        if (k === '__new') {
            bukaForm(0);
            return;
        }
        pstate.filterK = k;
        pel.chips.querySelectorAll('.chip').forEach(function (c) { c.classList.toggle('on', c === b && k !== '__new'); });
        haptic(6);
        renderList();
    };
}

/* ---------- Daftar barang ---------- */
var MAX_ITEM = 20;   // maksimal barang yang ditampilkan di daftar
function produkTerlihat() {
    return pstate.produk.filter(function (p) {
        var okK = pstate.filterK === 'all' || String(p.kategori_id) === String(pstate.filterK);
        var okQ = !pstate.q
            || p.nama.toLowerCase().indexOf(pstate.q) !== -1
            || (p.kategori || '').toLowerCase().indexOf(pstate.q) !== -1
            || (p.barcode || '').toLowerCase().indexOf(pstate.q) !== -1;
        var okL = !pstate.lowOnly || p.stok <= p.stok_minimal;
        return okK && okQ && okL;
    });
}

function renderList() {
    var list = produkTerlihat();
    pel.empty.hidden = list.length > 0;
    var stokTotal = 0, stokKritis = 0;
    pstate.produk.forEach(function (p) {
        stokTotal++;
        if (p.stok <= p.stok_minimal) stokKritis++;
    });
    if (stokKritis === 0) pstate.lowOnly = false;
    pel.stat.innerHTML = stokTotal + ' barang'
        + (stokKritis > 0
            ? ' <button type="button" class="low-pill' + (pstate.lowOnly ? ' on' : '') + '" id="btnLowStok">'
              + stokKritis + ' stok menipis' + (pstate.lowOnly ? ' &times;' : '') + '</button>'
            : '');

    var html = '';
    var totalTampil = list.length;
    list = list.slice(0, MAX_ITEM);
    list.forEach(function (p) {
        var stokCls = p.stok === 0 ? 'habis' : (p.stok <= p.stok_minimal ? 'low' : '');
        var stokTxt = p.stok === 0 ? 'Habis' : ('Stok ' + p.stok + (p.satuan && p.satuan !== 'pcs' ? ' ' + p.satuan : ''));
        html += '<div class="prow' + (p.stok === 0 ? ' habis' : '') + '" data-id="' + p.id + '" style="--h:' + catHue(p.kategori) + '">'
            + (p.baru ? '<span class="badge-new">BARU</span>' : '')
            + '<div class="prow-main">'
            + '<b class="prow-nama">' + esc(p.nama) + '</b>'
            + '<span class="prow-sub">' + esc(p.kategori || 'Lainnya')
            + (p.barcode ? ' <i class="prow-bc">' + esc(p.barcode) + '</i>' : '')
            + '</span>'
            + '</div>'
            + '<div class="prow-side">'
            + '<b class="prow-harga">' + rp(p.harga_jual) + '</b>'
            + '<span class="pstock ' + stokCls + '">' + stokTxt + '</span>'
            + '</div>'
            + '<svg class="chev" width="8" height="14" viewBox="0 0 10 17" fill="none"><path d="M1.5 1.5l7 7-7 7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            + '</div>';
    });
    if (totalTampil > MAX_ITEM) {
        html += '<div class="grid-more">Menampilkan ' + MAX_ITEM + ' dari ' + totalTampil + ' barang. Gunakan pencarian atau kategori.</div>';
    }
    pel.list.innerHTML = html;
}

document.addEventListener('click', function (ev) {
    if (!ev.target.closest('#btnLowStok')) return;
    pstate.lowOnly = !pstate.lowOnly;
    haptic(8);
    renderList();
});

pel_listClick();
function pel_listClick() {
    document.addEventListener('click', function (ev) {
        var row = ev.target.closest('.prow');
        if (!row || !document.getElementById('plist').contains(row)) return;
        bukaForm(Number(row.getAttribute('data-id')));
    });
}

/* ---------- Form tambah / ubah ---------- */
function bukaForm(id, presetNama, fokusKategori) {
    pstate.editId = id || 0;
    var p = id ? cariProduk(id) : null;

    // datalist kategori
    var opt = '';
    pstate.kategori.forEach(function (k) { opt += '<option value="' + esc(k.nama) + '">'; });
    pel.katList.innerHTML = opt;

    pel.formJudul.textContent = p ? 'Ubah Barang' : 'Tambah Barang';
    pel.fNama.value = p ? p.nama : (presetNama || '');
    pel.fKategori.value = p ? (p.kategori === 'Lainnya' ? '' : (p.kategori || '')) : '';
    pel.fBarcode.value = p ? (p.barcode || '') : '';
    pel.fBeli.value = p ? String(Math.round(p.harga_beli)) : '';
    pel.fJual.value = p ? String(Math.round(p.harga_jual)) : '';
    pel.fStok.value = p ? String(p.stok) : '';
    pel.fStokMin.value = p ? String(p.stok_minimal) : '5';
    pel.fSatuan.value = p ? (p.satuan || 'pcs') : 'pcs';
    pel.btnHapus.hidden = !p;
    pel.formInfo.textContent = p
        ? ('Kode barang #' + p.id + (p.baru ? ' • masih bertanda BARU' : ''))
        : 'Barang baru otomatis bertanda BARU selama 7 hari.';

    openSheet('sheetForm');
    setTimeout(function () {
        (fokusKategori ? pel.fKategori : pel.fNama).focus();
    }, 260);
}

function angka(el) {
    var v = parseInt(String(el.value).replace(/[^\d]/g, ''), 10);
    return isNaN(v) ? 0 : v;
}

async function simpan() {
    var nama = pel.fNama.value.trim();
    if (!nama) {
        toast('Nama barang wajib diisi', 'err');
        pel.fNama.focus();
        return;
    }
    var jual = angka(pel.fJual);
    if (jual <= 0) {
        toast('Harga jual harus lebih dari 0', 'err');
        pel.fJual.focus();
        return;
    }
    var data = {
        aksi: 'simpan',
        id: pstate.editId,
        nama: nama,
        kategori: pel.fKategori.value.trim(),
        barcode: pel.fBarcode.value.trim(),
        harga_beli: angka(pel.fBeli),
        harga_jual: jual,
        stok: angka(pel.fStok),
        stok_minimal: angka(pel.fStokMin),
        satuan: pel.fSatuan.value.trim() || 'pcs'
    };

    pel.btnSimpan.disabled = true;
    try {
        var j = await postJson('api/produk.php', data);
        toast(pstate.editId ? 'Barang diperbarui' : 'Barang ditambahkan');
        closeSheet('sheetForm');
        await muat();
        if (!pstate.editId && j.id) {
            // sorot barang baru di daftar
            var row = document.querySelector('.prow[data-id="' + j.id + '"]');
            if (row) {
                row.classList.add('flash');
                setTimeout(function () { row.classList.remove('flash'); }, 1600);
            }
        }
    } catch (e) {
        toast(e.message, 'err');
    }
    pel.btnSimpan.disabled = false;
}

async function hapus() {
    if (!pstate.editId) return;
    pel.btnHapusYa.disabled = true;
    try {
        await postJson('api/produk.php', { aksi: 'hapus', id: pstate.editId });
        pel.alertHapus.classList.remove('show');
        closeSheet('sheetForm');
        toast('Barang dihapus');
        await muat();
    } catch (e) {
        toast(e.message, 'err');
    }
    pel.btnHapusYa.disabled = false;
}

/* ============================================================
   CETAK LABEL BARCODE
   ============================================================ */
function bukaSheetLabel() {
    lstate.q = '';
    pel.lblSearch.value = '';
    lstate.pilih = {};
    renderLblList();
    setCopy(lstate.copy);
    updateLblInfo();
    openSheet('sheetLabel');
}

function renderLblList() {
    var list = pstate.produk.filter(function (p) {
        return !lstate.q
            || p.nama.toLowerCase().indexOf(lstate.q) !== -1
            || (p.barcode || '').toLowerCase().indexOf(lstate.q) !== -1;
    });

    if (!list.length) {
        pel.lblList.innerHTML = '<div class="lrow dis"><div class="lrow-main"><span class="lrow-nama">Tidak ada barang cocok</span></div></div>';
        return;
    }

    var html = '';
    list.forEach(function (p) {
        var ada = !!p.barcode;
        html += '<div class="lrow' + (ada ? '' : ' dis') + (lstate.pilih[p.id] ? ' on' : '') + '" data-id="' + p.id + '">'
            + '<div class="lrow-main">'
            + '<span class="lrow-nama">' + esc(p.nama) + '</span>'
            + '<span class="lrow-sub">' + (ada ? '<i class="bc">' + esc(p.barcode) + '</i>' : 'Tanpa barcode — isi dulu di form barang') + '</span>'
            + '</div>'
            + '<span class="lrow-harga">' + rp(p.harga_jual) + '</span>'
            + '<span class="ck"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5l5.5 5.5L20 6.5"/></svg></span>'
            + '</div>';
    });
    pel.lblList.innerHTML = html;
}

function pilihSemua() {
    var ada = false;
    pstate.produk.forEach(function (p) {
        if (!p.barcode) return;
        if (!lstate.q || p.nama.toLowerCase().indexOf(lstate.q) !== -1 || (p.barcode || '').toLowerCase().indexOf(lstate.q) !== -1) {
            lstate.pilih[p.id] = true;
            ada = true;
        }
    });
    renderLblList();
    updateLblInfo();
    haptic(10);
    if (!ada) toast('Belum ada barang yang punya barcode', 'err');
}

function setCopy(n) {
    lstate.copy = Math.max(1, Math.min(100, n || 1));
    pel.lblCopy.textContent = lstate.copy;
    updateLblInfo();
}

function jumlahTerpilih() {
    return Object.keys(lstate.pilih).length;
}

function updateLblInfo() {
    var n = jumlahTerpilih();
    pel.lblTersimpan.textContent = n + ' barang terpilih';
    pel.lblTotal.textContent = n * lstate.copy + ' label';
    pel.btnCetakLabel.disabled = n === 0;
}

function cetakLabelSubmit() {
    var ids = Object.keys(lstate.pilih).map(Number);
    if (!ids.length) return;

    var f = document.createElement('form');
    f.method = 'POST';
    f.action = 'cetak-label.php';
    f.target = '_blank';

    function isi(nama, nilai) {
        var i = document.createElement('input');
        i.type = 'hidden';
        i.name = nama;
        i.value = nilai;
        f.appendChild(i);
    }
    isi('ids', JSON.stringify(ids));
    isi('ukuran', lstate.ukuran);
    isi('copy', String(lstate.copy));

    document.body.appendChild(f);
    f.submit();
    setTimeout(function () { document.body.removeChild(f); }, 800);

    closeSheet('sheetLabel');
    toast('Halaman label dibuka di tab baru');
}
