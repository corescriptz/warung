/* ============================================================
   HALAMAN LAPORAN — kartu, grafik 7 hari, terlaris, ekspor
   ============================================================ */
'use strict';

var periode = 'hari';
var reportData = null;

document.addEventListener('DOMContentLoaded', function () {
    var seg = initSeg('#segPeriode', function (v) {
        periode = v;
        muatLaporan();
    });

    document.getElementById('btnExport').addEventListener('click', function () {
        window.location.href = 'api/laporan.php?export=xlsx&periode=' + periode;
    });

    document.getElementById('btnPrint').addEventListener('click', function () {
        haptic(8);
        window.open('cetak-laporan.php?periode=' + periode, '_blank');
    });

    document.getElementById('btnPrintStruk').addEventListener('click', function () {
        if (currentStruk) cetakStruk(currentStruk);
    });

    document.getElementById('lastList').addEventListener('click', function (ev) {
        var row = ev.target.closest('[data-id]');
        if (!row) return;
        bukaStruk(Number(row.getAttribute('data-id')));
    });

    muatLaporan();
});

async function muatLaporan() {
    try {
        var j = await api('api/laporan.php?periode=' + periode);
        reportData = j;
        renderSemua(j);
    } catch (e) {
        toast(e.message, 'err');
    }
}

function renderSemua(j) {
    document.getElementById('lapLabel').textContent = j.label;
    var r = j.ringkasan;
    countUp(document.getElementById('stOmzet'), r.omzet, rp);
    countUp(document.getElementById('stJumlah'), r.jumlah, function (n) { return Math.round(n).toString(); });
    countUp(document.getElementById('stLaba'), r.laba, rp);
    document.getElementById('stRata').textContent = r.jumlah > 0
        ? 'Rata-rata ' + rp(r.rata) + ' / transaksi'
        : 'Belum ada transaksi';

    renderChart(j.chart);
    renderTop(j.top);
    renderTerakhir(j.terakhir);
}

/* ---------- Grafik batang 7 hari ---------- */
function renderChart(chart) {
    var bars = document.getElementById('chartBars');
    var labels = document.getElementById('chartLabels');
    var max = Math.max.apply(null, chart.map(function (c) { return c.omzet; }));
    var total7 = chart.reduce(function (a, c) { return a + c.omzet; }, 0);
    document.getElementById('chartTotal').textContent = 'Total ' + rpShort(total7);

    var hb = '', hl = '';
    chart.forEach(function (c) {
        var h = max > 0 ? Math.max(4, Math.round(c.omzet / max * 100)) : 4;
        hb += '<div class="cbar' + (c.hari_ini ? ' today' : '') + (c.omzet <= 0 ? ' zero' : '') + '">'
            + '<span class="cbar-val">' + (c.omzet > 0 ? rpShort(c.omzet) : '') + '</span>'
            + '<div class="cbar-bar" style="height:' + h + '%"></div>'
            + '</div>';
        hl += '<span class="' + (c.hari_ini ? 'today' : '') + '">' + c.label + '</span>';
    });
    bars.innerHTML = hb;
    labels.innerHTML = hl;
    var wrap = document.getElementById('chart');
    wrap.classList.remove('on');
    requestAnimationFrame(function () {
        requestAnimationFrame(function () { wrap.classList.add('on'); });
    });
}

/* ---------- Produk terlaris ---------- */
function renderTop(top) {
    var box = document.getElementById('topList');
    var empty = document.getElementById('topEmpty');
    empty.hidden = top.length > 0;
    var html = '';
    top.forEach(function (t, i) {
        var rcls = i === 0 ? 'r1' : (i === 1 ? 'r2' : (i === 2 ? 'r3' : ''));
        html += '<div class="row-item">'
            + '<div class="rank ' + rcls + '">' + (i + 1) + '</div>'
            + '<div class="ri-main"><b>' + esc(t.nama) + '</b><span>' + t.qty + ' terjual</span></div>'
            + '<div class="ri-right"><b>' + rp(t.omzet) + '</b></div>'
            + '</div>';
    });
    box.innerHTML = html;
}

/* ---------- Transaksi terakhir ---------- */
function renderTerakhir(list) {
    var box = document.getElementById('lastList');
    var empty = document.getElementById('lastEmpty');
    empty.hidden = list.length > 0;
    var html = '';
    list.forEach(function (t) {
        var d = new Date(t.tanggal.replace(' ', 'T'));
        var jam = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
        var tgl = d.getDate() + '/' + (d.getMonth() + 1);
        html += '<div class="row-item tap" data-id="' + t.id + '" role="button">'
            + '<div class="ri-main"><b>' + esc(t.kode) + '</b><span>' + tgl + ' ' + jam + ' &middot; ' + t.item + ' barang</span></div>'
            + '<div class="ri-right"><b>' + rp(t.total) + '</b><span>' + esc(t.metode) + '</span></div>'
            + '<svg class="chev" width="8" height="14" viewBox="0 0 10 17" fill="none"><path d="M1.5 1.5l7 7-7 7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            + '</div>';
    });
    box.innerHTML = html;
}

async function bukaStruk(id) {
    try {
        var j = await api('api/transaksi.php?id=' + id);
        showStruk(j.transaksi);
    } catch (e) {
        toast(e.message, 'err');
    }
}
