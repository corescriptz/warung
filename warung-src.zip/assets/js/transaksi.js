/* ============================================================
   HALAMAN TRANSAKSI — katalog, keranjang, pembayaran, struk
   ============================================================ */
'use strict';

var state = {
    produk: [],
    kategori: [],
    filterK: 'all',
    q: '',
    cart: {},          // id -> {id, nama, harga, qty, stok, satuan}
    diskon: 0,
    metode: 'Tunai',
    bayarStr: '',
    kasir: 'Kasir'
};

var MAX_ITEM = 20;   // maksimal barang yang ditampilkan di daftar
var el = {};

document.addEventListener('DOMContentLoaded', init);

async function init() {
    el = {
        tokoNama: document.getElementById('tokoNama'),
        headDate: document.getElementById('headDate'),
        search: document.getElementById('searchInput'),
        searchClear: document.getElementById('searchClear'),
        chips: document.getElementById('chips'),
        grid: document.getElementById('grid'),
        empty: document.getElementById('emptyState'),
        cartbar: document.getElementById('cartbar'),
        cartInfoQty: document.getElementById('cartInfoQty'),
        cartInfoTotal: document.getElementById('cartInfoTotal'),
        btnOpenCart: document.getElementById('btnOpenCart'),
        sheetCart: document.getElementById('sheetCart'),
        cartItems: document.getElementById('cartItems'),
        btnClearCart: document.getElementById('btnClearCart'),
        sumSubtotal: document.getElementById('sumSubtotal'),
        diskonInput: document.getElementById('diskonInput'),
        sumTotal: document.getElementById('sumTotal'),
        btnToPay: document.getElementById('btnToPay'),
        sheetPay: document.getElementById('sheetPay'),
        payTotal: document.getElementById('payTotal'),
        payTotalNon: document.getElementById('payTotalNon'),
        quickChips: document.getElementById('quickChips'),
        kembaliBox: document.getElementById('kembaliBox'),
        payKembali: document.getElementById('payKembali'),
        keypad: document.getElementById('keypad'),
        payTunai: document.getElementById('payTunai'),
        payNonTunai: document.getElementById('payNonTunai'),
        btnConfirmPay: document.getElementById('btnConfirmPay'),
        successOverlay: document.getElementById('successOverlay'),
        successKode: document.getElementById('successKode'),
        successKembali: document.getElementById('successKembali'),
        successKembaliLabel: document.getElementById('successKembaliLabel'),
        btnNewTx: document.getElementById('btnNewTx'),
        btnSuccessPrint: document.getElementById('btnSuccessPrint'),
        btnSuccessStruk: document.getElementById('btnSuccessStruk'),
        btnPrintStruk: document.getElementById('btnPrintStruk'),
        btnKasir: document.getElementById('btnKasir'),
        kasirNama: document.getElementById('kasirNama'),
        alertKasir: document.getElementById('alertKasir'),
        kasirInput: document.getElementById('kasirInput'),
        btnKasirSimpan: document.getElementById('btnKasirSimpan'),
        btnScan: document.getElementById('btnScan'),
        sheetScan: document.getElementById('sheetScan'),
        scanVideo: document.getElementById('scanVideo'),
        scanMsg: document.getElementById('scanMsg')
    };

    el.headDate.textContent = tanggalIndo();
    muatKeranjang();
    initKasir();
    initScanner();

    el.search.addEventListener('input', function () {
        state.q = el.search.value.trim().toLowerCase();
        el.searchClear.classList.toggle('show', state.q.length > 0);
        renderGrid();
    });
    el.searchClear.addEventListener('click', function () {
        el.search.value = '';
        state.q = '';
        el.searchClear.classList.remove('show');
        renderGrid();
        el.search.focus();
    });

    el.btnOpenCart.addEventListener('click', function () { renderCartSheet(); openSheet('sheetCart'); });
    el.btnClearCart.addEventListener('click', function () {
        if (!Object.keys(state.cart).length) return;
        state.cart = {};
        state.diskon = 0;
        el.diskonInput.value = '';
        simpanKeranjang();
        renderCartBar(); renderCartSheet(); renderGrid();
        toast('Keranjang dikosongkan');
    });
    el.diskonInput.addEventListener('input', function () {
        var v = parseInt(el.diskonInput.value.replace(/[^\d]/g, ''), 10);
        state.diskon = isNaN(v) ? 0 : v;
        renderCartSummary();
    });
    el.btnToPay.addEventListener('click', bukaPembayaran);

    // Pembayaran
    initSeg('#segMetode', function (v) {
        state.metode = v;
        var tunai = v === 'Tunai';
        el.payTunai.hidden = !tunai;
        el.payNonTunai.hidden = tunai;
        renderPayState();
    });
    el.quickChips.addEventListener('click', function (ev) {
        var b = ev.target.closest('button[data-cash]');
        if (!b) return;
        haptic(8);
        var total = cartTotals().total;
        state.bayarStr = (b.getAttribute('data-cash') === 'pas') ? String(total) : b.getAttribute('data-cash');
        renderPayState();
    });
    el.keypad.addEventListener('click', function (ev) {
        var b = ev.target.closest('button[data-k]');
        if (!b) return;
        haptic(6);
        var k = b.getAttribute('data-k');
        if (k === 'back') {
            state.bayarStr = state.bayarStr.slice(0, -1);
        } else {
            if (state.bayarStr.length > 12) return;
            state.bayarStr = (state.bayarStr === '0') ? k : state.bayarStr + k;
        }
        renderPayState();
    });
    el.btnConfirmPay.addEventListener('click', checkout);

    // Sukses
    el.btnNewTx.addEventListener('click', function () {
        // Transaksi baru: cukup tutup overlay, keranjang sudah kosong
        el.successOverlay.classList.remove('show');
    });
    el.btnSuccessStruk.addEventListener('click', function () {
        el.successOverlay.classList.remove('show');
        if (window._lastTransaksi) showStruk(window._lastTransaksi);
    });
    el.btnSuccessPrint.addEventListener('click', function () {
        if (window._lastTransaksi) cetakStruk(window._lastTransaksi);
    });
    el.btnPrintStruk.addEventListener('click', function () {
        if (currentStruk) cetakStruk(currentStruk);
    });

    await muatProduk();
    renderCartBar();
}

/* ---------- Data ---------- */
async function muatProduk() {
    el.grid.innerHTML = '<div class="skel"></div><div class="skel"></div><div class="skel"></div><div class="skel"></div>';
    try {
        var j = await api('api/produk.php');
        state.produk = j.produk;
        state.kategori = j.kategori;
        el.tokoNama.textContent = (j.toko && j.toko.nama) || 'Warung';
        if (j.kasir) { state.kasir = j.kasir; }
        sesuaikanKeranjang();
        el.kasirNama.textContent = state.kasir;
        renderChips();
        renderGrid();
    } catch (e) {
        el.grid.innerHTML = '';
        toast(e.message, 'err');
    }
}

/**
 * Keranjang tersimpan di localStorage bisa basi (harga diubah, stok habis,
 * barang dihapus). Samakan dengan data terbaru dari server.
 */
function sesuaikanKeranjang() {
    var berubah = false;
    Object.keys(state.cart).forEach(function (k) {
        var it = state.cart[k];
        var p = state.produk.filter(function (x) { return x.id === it.id; })[0];
        if (!p || p.stok <= 0) { delete state.cart[k]; berubah = true; return; }
        if (it.harga !== p.harga_jual || it.stok !== p.stok || it.nama !== p.nama) {
            it.harga = p.harga_jual; it.stok = p.stok; it.nama = p.nama; it.satuan = p.satuan;
            berubah = true;
        }
        if (it.qty > p.stok) { it.qty = p.stok; berubah = true; }
    });
    if (berubah) {
        simpanKeranjang();
        renderCartBar();
        renderCartSheet();
        toast('Keranjang disesuaikan dengan stok & harga terbaru');
    }
}

/* ---------- Katalog ---------- */
function renderChips() {
    var html = '<button class="chip on" data-k="all" style="--h:250">Semua</button>';
    state.kategori.forEach(function (k) {
        html += '<button class="chip" data-k="' + k.id + '" style="--h:' + catHue(k.nama) + '"><i class="cd"></i>' + esc(k.nama) + '</button>';
    });
    el.chips.innerHTML = html;
    el.chips.onclick = function (ev) {
        var b = ev.target.closest('.chip');
        if (!b) return;
        el.chips.querySelectorAll('.chip').forEach(function (c) { c.classList.toggle('on', c === b); });
        state.filterK = b.getAttribute('data-k');
        haptic(6);
        renderGrid();
    };
}

function produkTerlihat() {
    return state.produk.filter(function (p) {
        var okK = state.filterK === 'all' || String(p.kategori_id) === String(state.filterK);
        var okQ = !state.q || p.nama.toLowerCase().indexOf(state.q) !== -1 || (p.kategori || '').toLowerCase().indexOf(state.q) !== -1 || (p.barcode || '').toLowerCase().indexOf(state.q) !== -1;
        return okK && okQ;
    });
}

/** Penanda "+" / jumlah di keranjang pada kartu produk */
function dotHtml(id) {
    var c = state.cart[id];
    return '<span class="plus-dot' + (c ? ' has' : '') + '">' + (c ? c.qty : '+') + '</span>';
}
function updateCardDot(id) {
    var card = document.querySelector('.pcard[data-id="' + id + '"]');
    var dot = card && card.querySelector('.plus-dot');
    if (!dot) return;
    var c = state.cart[id];
    dot.classList.toggle('has', !!c);
    dot.textContent = c ? c.qty : '+';
}

function renderGrid() {
    var list = produkTerlihat();
    el.empty.hidden = list.length > 0;
    var html = '';
    var total = list.length;
    list = list.slice(0, MAX_ITEM);
    list.forEach(function (p) {
        var stokCls = p.stok === 0 ? 'habis' : (p.stok <= p.stok_minimal ? 'low' : '');
        var stokTxt = p.stok === 0 ? 'Habis' : ('Stok ' + p.stok + (p.satuan && p.satuan !== 'pcs' ? ' ' + p.satuan : ''));
        html += '<div class="pcard' + (p.stok === 0 ? ' habis' : '') + '" data-id="' + p.id + '" style="--h:' + catHue(p.kategori) + '">'
            + (p.baru ? '<span class="badge-new">BARU</span>' : '')
            + '<span class="pname">' + esc(p.nama) + '</span>'
            + '<span class="pprice">' + rp(p.harga_jual) + '</span>'
            + '<span class="pstock ' + stokCls + '">' + stokTxt + '</span>'
            + (p.stok > 0 ? dotHtml(p.id) : '')
            + '</div>';
    });
    if (total > MAX_ITEM) {
        html += '<div class="grid-more">Menampilkan ' + MAX_ITEM + ' dari ' + total + ' barang. Gunakan pencarian atau kategori.</div>';
    }
    el.grid.innerHTML = html;
}

el_gridClick();
function el_gridClick() {
    document.addEventListener('click', function (ev) {
        var card = ev.target.closest('.pcard');
        if (!card || !document.getElementById('grid').contains(card)) return;
        var id = Number(card.getAttribute('data-id'));
        tambahKeKeranjang(id, 1, card);
    });
}

/* ---------- Keranjang ---------- */
function tambahKeKeranjang(id, qty, cardEl) {
    var p = state.produk.filter(function (x) { return x.id === id; })[0];
    if (!p) return;
    var cur = state.cart[id];
    var newQty = (cur ? cur.qty : 0) + qty;
    if (newQty > p.stok) {
        toast('Stok "' + p.nama + '" hanya ' + p.stok, 'err');
        return;
    }
    state.cart[id] = { id: p.id, nama: p.nama, harga: p.harga_jual, qty: newQty, stok: p.stok, satuan: p.satuan };
    haptic(10);
    if (cardEl) {
        cardEl.classList.remove('pop');
        void cardEl.offsetWidth;
        cardEl.classList.add('pop');
    }
    simpanKeranjang();
    renderCartBar();
    updateCardDot(id);
}

function cartTotals() {
    var subtotal = 0, qty = 0;
    Object.keys(state.cart).forEach(function (k) {
        var it = state.cart[k];
        subtotal += it.harga * it.qty;
        qty += it.qty;
    });
    var diskon = Math.min(state.diskon, subtotal);
    return { subtotal: subtotal, qty: qty, total: subtotal - diskon };
}

var _lastCartQty = 0;
function renderCartBar() {
    var t = cartTotals();
    if (t.qty > 0) {
        el.cartbar.classList.add('show');
        if (t.qty > _lastCartQty) {
            el.cartbar.classList.remove('bounce');
            void el.cartbar.offsetWidth;
            el.cartbar.classList.add('bounce');
        }
        el.cartInfoQty.textContent = t.qty + ' barang';
        el.cartInfoTotal.textContent = rp(t.total);
    } else {
        el.cartbar.classList.remove('show');
    }
    _lastCartQty = t.qty;
}

function renderCartSheet() {
    var html = '';
    Object.keys(state.cart).forEach(function (k) {
        var it = state.cart[k];
        html += '<div class="citem">'
            + '<div class="citem-info"><b>' + esc(it.nama) + '</b><span>' + rp(it.harga) + ' / ' + esc(it.satuan || 'pcs') + '</span></div>'
            + '<div class="qty-step">'
            + '<button data-act="min" data-id="' + it.id + '" ' + (it.qty <= 1 ? 'disabled' : '') + '>&minus;</button>'
            + '<b>' + it.qty + '</b>'
            + '<button data-act="plus" data-id="' + it.id + '" ' + (it.qty >= it.stok ? 'disabled' : '') + '>+</button>'
            + '</div>'
            + '<div class="citem-total">' + rp(it.harga * it.qty) + '</div>'
            + '<button class="citem-del" data-act="del" data-id="' + it.id + '" aria-label="Hapus">'
            + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M9 7V5a1.6 1.6 0 0 1 1.6-1.6h2.8A1.6 1.6 0 0 1 15 5v2M6.5 7l1 12a2 2 0 0 0 2 1.8h5a2 2 0 0 0 2-1.8l1-12"/></svg>'
            + '</button>'
            + '</div>';
    });
    el.cartItems.innerHTML = html || '<div class="empty-mini">Keranjang masih kosong.<br>Tap barang untuk menambahkan.</div>';
    renderCartSummary();
}

el_cartClick();
function el_cartClick() {
    document.addEventListener('click', function (ev) {
        var b = ev.target.closest('[data-act]');
        if (!b) return;
        var id = Number(b.getAttribute('data-id'));
        var act = b.getAttribute('data-act');
        var it = state.cart[id];
        if (!it) return;
        if (act === 'plus' && it.qty < it.stok) it.qty++;
        else if (act === 'min' && it.qty > 1) it.qty--;
        else if (act === 'del') { delete state.cart[id]; }
        else return;
        haptic(8);
        simpanKeranjang();
        renderCartSheet();
        renderCartBar();
        renderGrid();
    });
}

function renderCartSummary() {
    var t = cartTotals();
    el.sumSubtotal.textContent = rp(t.subtotal);
    el.sumTotal.textContent = rp(t.total);
    el.btnToPay.disabled = t.qty === 0;
}

function simpanKeranjang() {
    try { localStorage.setItem('wk_cart', JSON.stringify(state.cart)); } catch (e) {}
}
function muatKeranjang() {
    try {
        var c = JSON.parse(localStorage.getItem('wk_cart') || '{}');
        if (c && typeof c === 'object') state.cart = c;
    } catch (e) {}
}

/* ---------- Kasir aktif ---------- */
function initKasir() {
    el.btnKasir.addEventListener('click', function () {
        el.kasirInput.value = state.kasir === 'Kasir' ? '' : state.kasir;
        el.alertKasir.classList.add('show');
        haptic(8);
        setTimeout(function () { el.kasirInput.focus(); }, 120);
    });
    el.alertKasir.addEventListener('click', function (ev) {
        if (ev.target.closest('[data-alert-close]')) {
            el.alertKasir.classList.remove('show');
        }
    });
    el.kasirInput.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') el.btnKasirSimpan.click();
    });
    el.btnKasirSimpan.addEventListener('click', async function () {
        var nama = el.kasirInput.value.trim();
        if (!nama) {
            toast('Nama kasir tidak boleh kosong', 'err');
            el.kasirInput.focus();
            return;
        }
        el.btnKasirSimpan.disabled = true;
        try {
            await postJson('api/pengaturan.php', { kasir_nama: nama });
            state.kasir = nama;
            el.kasirNama.textContent = nama;
            el.alertKasir.classList.remove('show');
            toast('Kasir: ' + nama);
        } catch (e) {
            toast(e.message, 'err');
        }
        el.btnKasirSimpan.disabled = false;
    });
}

/* ---------- Barcode scanner (USB keyboard-wedge + kamera) ---------- */
var _scanStream = null, _scanTimer = null;

function initScanner() {
    // Tombol kamera hanya muncul bila browser mendukung BarcodeDetector
    var kameraOk = ('BarcodeDetector' in window)
        && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;
    if (kameraOk && el.btnScan) {
        el.btnScan.hidden = false;
        el.btnScan.addEventListener('click', bukaKamera);
    }
    if (el.sheetScan) {
        el.sheetScan.addEventListener('click', function (ev) {
            if (ev.target.closest('[data-close="sheetScan"]')) stopKamera();
        });
    }

    // Scanner USB/Bluetooth bekerja seperti keyboard: mengetik kode sangat
    // cepat lalu diakhiri Enter. Rekam pola itu di seluruh halaman.
    var buf = '', lastAt = 0, mulai = 0;
    document.addEventListener('keydown', function (ev) {
        if (ev.ctrlKey || ev.metaKey || ev.altKey) { buf = ''; return; }

        // Jangan ganggu dialog kasir / sheet pembayaran / overlay sukses
        if ((el.alertKasir && el.alertKasir.classList.contains('show'))
            || el.sheetPay.classList.contains('open')
            || el.successOverlay.classList.contains('show')) {
            buf = '';
            return;
        }

        if (ev.key === 'Enter') {
            var kode = buf;
            buf = '';
            if (kode.length >= 5 && Date.now() - mulai < 2500) {
                if (prosesBarcode(kode) && ev.target === el.search) {
                    ev.preventDefault();
                }
            }
            return;
        }

        if (ev.key && ev.key.length === 1) {
            var now = Date.now();
            if (now - lastAt > 90) { buf = ev.key; mulai = now; }
            else { buf += ev.key; }
            lastAt = now;
            if (buf.length > 64) { buf = buf.slice(-64); mulai = now; }
        } else {
            buf = '';
        }
    });
}

/** Cari produk berdasar barcode lalu tambahkan ke keranjang. */
function prosesBarcode(kode) {
    kode = String(kode).trim();
    if (!kode) return false;
    var p = null;
    for (var i = 0; i < state.produk.length; i++) {
        if ((state.produk[i].barcode || '') === kode) { p = state.produk[i]; break; }
    }
    if (!p) {
        toast('Barcode tidak ditemukan: ' + kode, 'err');
        haptic(50);
        return false;
    }

    var sebelum = state.cart[p.id] ? state.cart[p.id].qty : 0;
    tambahKeKeranjang(p.id, 1, null);
    var sesudah = state.cart[p.id] ? state.cart[p.id].qty : 0;
    if (sesudah > sebelum) {
        toast('Ditambah: ' + p.nama + (sesudah > 1 ? ' x' + sesudah : ''));
        haptic(14);
        if (el.sheetCart.classList.contains('open')) renderCartSheet();
        if (state.q) {
            el.search.value = '';
            state.q = '';
            el.searchClear.classList.remove('show');
            renderGrid();
        }
    }
    return sesudah > sebelum;
}

async function bukaKamera() {
    if (!('BarcodeDetector' in window)) return;
    try {
        openSheet('sheetScan');
        el.scanMsg.textContent = 'Membuka kamera\u2026';
        var det;
        try {
            det = new BarcodeDetector({ formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'itf', 'qr_code'] });
        } catch (e) {
            det = new BarcodeDetector();
        }
        _scanStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        el.scanVideo.srcObject = _scanStream;
        await el.scanVideo.play();
        el.scanMsg.textContent = 'Arahkan barcode ke dalam kotak';
        _scanTimer = setInterval(async function () {
            if (!_scanStream || el.scanVideo.readyState < 2) return;
            try {
                var codes = await det.detect(el.scanVideo);
                if (codes && codes.length) {
                    var kode = codes[0].rawValue;
                    stopKamera();
                    closeSheet('sheetScan');
                    prosesBarcode(kode);
                }
            } catch (e) { /* frame bocor, abaikan */ }
        }, 350);
    } catch (e) {
        stopKamera();
        closeSheet('sheetScan');
        toast('Kamera tidak bisa dibuka: ' + (e.message || 'izin ditolak'), 'err');
    }
}

function stopKamera() {
    if (_scanTimer) { clearInterval(_scanTimer); _scanTimer = null; }
    if (_scanStream) {
        try { _scanStream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
        _scanStream = null;
    }
    if (el.scanVideo) el.scanVideo.srcObject = null;
}

/* ---------- Pembayaran ---------- */
function bukaPembayaran() {
    closeSheet('sheetCart');
    state.bayarStr = '';
    setTimeout(function () {
        renderPayState();
        openSheet('sheetPay');
    }, 180);
}

function renderPayState() {
    var t = cartTotals();
    el.payTotal.textContent = rp(t.total);
    el.payTotalNon.textContent = rp(t.total);

    var bayar = parseInt(state.bayarStr || '0', 10) || 0;
    if (state.metode === 'Tunai') {
        var selisih = bayar - t.total;
        if (bayar === 0) {
            el.kembaliBox.classList.remove('kurang');
            el.payKembali.textContent = rp(0);
            el.payKembali.style.color = 'var(--txt2)';
        } else if (selisih >= 0) {
            el.kembaliBox.classList.remove('kurang');
            el.payKembali.textContent = rp(selisih);
            el.payKembali.style.color = 'var(--green)';
        } else {
            el.kembaliBox.classList.add('kurang');
            el.payKembali.textContent = 'Kurang ' + rp(-selisih);
            el.payKembali.style.color = 'var(--red)';
        }
        el.btnConfirmPay.disabled = !(bayar >= t.total && t.qty > 0);
    } else {
        el.btnConfirmPay.disabled = t.qty === 0;
    }
}

async function checkout() {
    var t = cartTotals();
    var bayar = state.metode === 'Tunai' ? (parseInt(state.bayarStr || '0', 10) || 0) : t.total;
    var items = Object.keys(state.cart).map(function (k) {
        return { id: state.cart[k].id, qty: state.cart[k].qty };
    });
    el.btnConfirmPay.disabled = true;
    try {
        var j = await postJson('api/transaksi.php', {
            items: items,
            diskon: state.diskon,
            metode: state.metode,
            bayar: bayar,
            kasir: state.kasir
        });
        window._lastTransaksi = j.transaksi;
        state.cart = {};
        state.diskon = 0;
        el.diskonInput.value = '';
        state.bayarStr = '';
        simpanKeranjang();
        closeSheet('sheetPay');

        var kembali = j.transaksi.kembalian;
        el.successKode.textContent = j.transaksi.kode;
        el.successKembali.textContent = rp(kembali);
        el.successKembaliLabel.textContent = (j.transaksi.metode === 'Tunai' && kembali > 0) ? 'Kembalian' : 'Uang Kembali';
        var kc = document.querySelector('.kembali-card');
        kc.classList.toggle('zero', !(j.transaksi.metode === 'Tunai' && kembali > 0));

        renderCartBar();
        renderCartSheet();
        muatProduk(); // stok berubah

        setTimeout(function () {
            el.successOverlay.classList.add('show');
            haptic([15, 60, 20]);
        }, 240);
    } catch (e) {
        toast(e.message, 'err');
        el.btnConfirmPay.disabled = false;
    }
}
