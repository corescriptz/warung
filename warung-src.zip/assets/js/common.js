/* ============================================================
   WARUNG KELONTONG POS — Skrip bersama
   ============================================================ */
'use strict';

/* ---------- Format ---------- */
function rp(n) {
    n = Math.round(Number(n) || 0);
    var neg = n < 0;
    var s = Math.abs(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return (neg ? '-Rp ' : 'Rp ') + s;
}

/* Format singkat utk grafik: 120000 -> "120rb", 2500000 -> "2,5jt" */
function rpShort(n) {
    n = Number(n) || 0;
    if (n >= 1000000) {
        var jt = n / 1000000;
        return (jt >= 10 ? Math.round(jt) : jt.toFixed(1).replace('.', ',').replace(',0', '')) + 'jt';
    }
    if (n >= 1000) {
        var rb = n / 1000;
        return (rb >= 100 ? Math.round(rb) : rb.toFixed(0)) + 'rb';
    }
    return Math.round(n).toString();
}

var HARI_ID = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
var BULAN_ID = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

function tanggalIndo(d) {
    d = d || new Date();
    return HARI_ID[(d.getDay() + 6) % 7] + ', ' + d.getDate() + ' ' + BULAN_ID[d.getMonth()] + ' ' + d.getFullYear();
}

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ---------- API helper ---------- */
async function api(url, opts) {
    opts = opts || {};
    try {
        var res = await fetch(url, opts);
        var ct = res.headers.get('content-type') || '';
        if (ct.indexOf('json') === -1) {
            if (!res.ok) throw new Error('Server error ' + res.status);
            return { ok: true, raw: res };
        }
        var j = await res.json();
        if (!res.ok) throw new Error(j.error || ('HTTP ' + res.status));
        return j;
    } catch (e) {
        if (e instanceof SyntaxError) throw new Error('Respons server tidak valid');
        throw e;
    }
}

function postJson(url, data) {
    return api(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
}

/* ---------- Toast ---------- */
var _toastTimer = null;
function toast(msg, type) {
    var t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast show' + (type === 'err' ? ' err' : '');
    clearTimeout(_toastTimer);
    _toastTimer = setTimeout(function () { t.className = 'toast' + (type === 'err' ? ' err' : ''); }, 2300);
}

/* ---------- Haptic ringan ---------- */
function haptic(ms) {
    try { if (navigator.vibrate) navigator.vibrate(ms || 8); } catch (e) {}
}

/* ---------- Sheets ---------- */
function openSheet(id) {
    var w = document.getElementById(id);
    if (!w) return;
    w.classList.add('open');
    document.body.classList.add('sheet-open');
}
function closeSheet(id) {
    var w = document.getElementById(id);
    if (!w) return;
    w.classList.remove('open');
    if (!document.querySelector('.sheet-wrap.open, .import-overlay.show, .success-overlay.show')) {
        document.body.classList.remove('sheet-open');
    }
}
document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-close]');
    if (el) { closeSheet(el.getAttribute('data-close')); }
});

/* ---------- Warna kategori (konsisten di semua halaman) ---------- */
var KAT_HUES = [250, 330, 25, 160, 200, 280, 45, 345, 175, 215, 95, 305];
function catHue(nama) {
    var s = String(nama || 'Lainnya'), h = 0;
    for (var i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) >>> 0; }
    return KAT_HUES[h % KAT_HUES.length];
}
function initialOf(nama) {
    var m = String(nama || '?').trim().match(/[A-Za-z0-9\u00C0-\u024F]/);
    return m ? m[0].toUpperCase() : '?';
}

/* ---------- Tombol Esc menutup sheet paling atas ---------- */
document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Escape') return;
    var open = document.querySelectorAll('.sheet-wrap.open');
    if (!open.length) return;
    var w = open[open.length - 1];
    var btn = w.querySelector('[data-close]');
    if (btn) btn.click();
});

/* ---------- Jam (hanya bila elemen ada) ---------- */
function tickClock() {
    var el = document.getElementById('sbTime');
    if (!el) return;
    var d = new Date();
    el.textContent = d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0');
}
tickClock();
setInterval(tickClock, 15000);

/* ---------- Segmented control ---------- */
function initSeg(rootSel, onChange) {
    var root = typeof rootSel === 'string' ? document.querySelector(rootSel) : rootSel;
    if (!root) return null;
    var thumb = root.querySelector('.seg-thumb');
    var btns = Array.prototype.slice.call(root.querySelectorAll('button'));
    function activate(btn) {
        var idx = btns.indexOf(btn);
        btns.forEach(function (b) { b.classList.toggle('on', b === btn); });
        if (thumb) thumb.style.transform = 'translateX(' + (idx * 100) + '%)';
        haptic(6);
        if (onChange) onChange(btn.getAttribute('data-v'), btn);
    }
    btns.forEach(function (b) {
        b.addEventListener('click', function () {
            if (!b.classList.contains('on')) activate(b);
        });
    });
    return {
        set: function (val) {
            var target = btns.filter(function (b) { return b.getAttribute('data-v') === val; })[0] || btns[0];
            activate(target);
        },
        get: function () {
            var on = btns.filter(function (b) { return b.classList.contains('on'); })[0];
            return on ? on.getAttribute('data-v') : null;
        }
    };
}

/* ---------- Struk ---------- */
var currentStruk = null;

function strukHTML(t) {
    var lebar = (window.APP && Number(window.APP.lebar) === 80) ? 380 : 292;
    var rows = '';
    (t.items || []).forEach(function (it) {
        rows += '<div class="rowline"><span>' + esc(it.nama) + '</span><span>' + rp(it.subtotal) + '</span></div>'
              + '<div class="rowline sub"><span>' + it.qty + ' ' + esc(it.satuan || 'pcs') + ' x ' + rp(it.harga) + '</span><span></span></div>';
    });
    var tgl = '';
    if (t.tanggal) {
        var m = String(t.tanggal).match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);
        tgl = m ? (m[3] + '/' + m[2] + '/' + m[1] + ' ' + m[4] + ':' + m[5]) : String(t.tanggal);
    }
    var html =
        '<div class="struk" style="width:' + lebar + 'px">'
        + '<div class="c bold big">' + esc(t.toko && t.toko.nama ? t.toko.nama : 'TOKO') + '</div>'
        + (t.toko && t.toko.alamat ? '<div class="c gray">' + esc(t.toko.alamat) + '</div>' : '')
        + (t.toko && t.toko.telp ? '<div class="c gray">Telp. ' + esc(t.toko.telp) + '</div>' : '')
        + '<div class="dashed"></div>'
        + '<div class="rowline"><span>' + esc(t.kode) + '</span><span>' + esc(tgl) + '</span></div>'
        + '<div class="gray">Kasir: ' + esc(t.kasir || '-') + ' &middot; ' + esc(t.metode || 'Tunai') + '</div>'
        + '<div class="dashed"></div>'
        + rows
        + '<div class="dashed"></div>'
        + '<div class="rowline"><span>Subtotal</span><span>' + rp(t.subtotal) + '</span></div>'
        + (t.diskon > 0 ? '<div class="rowline"><span>Diskon</span><span>-' + rp(t.diskon) + '</span></div>' : '')
        + '<div class="rowline bold big"><span>TOTAL</span><span>' + rp(t.total) + '</span></div>'
        + '<div class="rowline"><span>Bayar (' + esc(t.metode || 'Tunai') + ')</span><span>' + rp(t.bayar) + '</span></div>'
        + '<div class="rowline bold"><span>Kembalian</span><span>' + rp(t.kembalian) + '</span></div>'
        + '<div class="dashed"></div>'
        + (t.toko && t.toko.footer ? '<div class="c">' + esc(t.toko.footer) + '</div>' : '')
        + '<div class="c gray">--- ' + esc((window.APP && window.APP.versi) ? 'WK POS v' + window.APP.versi : '') + ' ---</div>'
        + '</div>';
    return html;
}

function showStruk(t) {
    currentStruk = t;
    var body = document.getElementById('strukBody');
    if (body) body.innerHTML = strukHTML(t);
    openSheet('sheetStruk');
}

function cetakStruk(t) {
    var area = document.getElementById('printArea');
    if (!area) return;
    area.innerHTML = strukHTML(t);
    document.body.classList.add('printing-struk');
    var done = function () {
        document.body.classList.remove('printing-struk');
        window.removeEventListener('afterprint', done);
    };
    window.addEventListener('afterprint', done);
    setTimeout(function () { window.print(); }, 60);
}

/* ---------- Animasi angka ---------- */
function countUp(el, target, formatter, dur) {
    dur = dur || 650;
    var start = performance.now();
    var from = Number(el.dataset.v || 0);
    target = Number(target) || 0;
    el.dataset.v = target;
    function frame(now) {
        var p = Math.min(1, (now - start) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = formatter(from + (target - from) * eased);
        if (p < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
}
