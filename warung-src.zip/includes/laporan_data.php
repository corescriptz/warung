<?php
/**
 * Kumpulan query laporan — dipakai bersama oleh:
 *  - api/laporan.php   (JSON + ekspor xlsx)
 *  - cetak-laporan.php (halaman cetak A4)
 */

function laporan_data(PDO $pdo, string $periode): array
{
    if (!in_array($periode, ['hari', 'minggu', 'bulan'], true)) {
        $periode = 'hari';
    }

    // Kondisi tanggal per periode
    switch ($periode) {
        case 'minggu':
            $where = 't.tanggal >= CURDATE() - INTERVAL 6 DAY';
            $label = '7 Hari Terakhir';
            break;
        case 'bulan':
            $where = "t.tanggal >= DATE_FORMAT(CURDATE(), '%Y-%m-01')";
            $label = 'Bulan Ini';
            break;
        default:
            $where = 't.tanggal >= CURDATE()';
            $label = 'Hari Ini';
            break;
    }

    /* ---------- Ringkasan ---------- */
    $r = $pdo->query("SELECT COUNT(*) AS j, COALESCE(SUM(t.total),0) AS omzet, COALESCE(SUM(t.laba),0) AS laba
                      FROM transaksi t WHERE $where")->fetch();
    $jumlah = (int)$r['j'];
    $omzet = (float)$r['omzet'];
    $laba = (float)$r['laba'];

    $r = $pdo->query("SELECT COALESCE(SUM(td.qty),0) AS q FROM transaksi_detail td
                      JOIN transaksi t ON t.id = td.transaksi_id WHERE $where")->fetch();
    $produkTerjual = (int)$r['q'];

    /* ---------- Grafik 7 hari terakhir ---------- */
    $rows = $pdo->query("SELECT DATE(t.tanggal) AS d, COALESCE(SUM(t.total),0) AS omzet
                         FROM transaksi t
                         WHERE t.tanggal >= CURDATE() - INTERVAL 6 DAY
                         GROUP BY DATE(t.tanggal)")->fetchAll();
    $perDay = [];
    foreach ($rows as $row) {
        $perDay[$row['d']] = (float)$row['omzet'];
    }
    $chart = [];
    for ($i = 6; $i >= 0; $i--) {
        $ts = strtotime(date('Y-m-d') . " -$i day");
        $d = date('Y-m-d', $ts);
        $chart[] = [
            'tanggal' => $d,
            'label'   => substr(hari_indo((int)date('N', $ts)), 0, 3),
            'omzet'   => isset($perDay[$d]) ? (float)$perDay[$d] : 0.0,
            'hari_ini' => ($i === 0),
        ];
    }

    /* ---------- Produk terlaris ---------- */
    $top = [];
    $st = $pdo->query("SELECT td.nama_produk, SUM(td.qty) AS qty, SUM(td.subtotal) AS omzet
                       FROM transaksi_detail td JOIN transaksi t ON t.id = td.transaksi_id
                       WHERE $where
                       GROUP BY td.produk_id, td.nama_produk
                       ORDER BY qty DESC, omzet DESC LIMIT 5");
    foreach ($st as $row) {
        $top[] = ['nama' => $row['nama_produk'], 'qty' => (int)$row['qty'], 'omzet' => (float)$row['omzet']];
    }

    /* ---------- Transaksi terakhir (10) ---------- */
    $terakhir = [];
    $st = $pdo->query("SELECT t.id, t.kode, t.tanggal, t.total, t.metode,
                       (SELECT COALESCE(SUM(td.qty),0) FROM transaksi_detail td WHERE td.transaksi_id = t.id) AS item
                       FROM transaksi t WHERE $where ORDER BY t.tanggal DESC, t.id DESC LIMIT 10");
    foreach ($st as $row) {
        $terakhir[] = [
            'id'     => (int)$row['id'],
            'kode'   => $row['kode'],
            'tanggal'=> $row['tanggal'],
            'total'  => (float)$row['total'],
            'metode' => $row['metode'],
            'item'   => (int)$row['item'],
        ];
    }

    /* ---------- Semua transaksi periode (untuk ekspor & cetak) ---------- */
    $semua = [];
    $st = $pdo->query("SELECT t.tanggal, t.kode, t.metode, t.kasir, t.subtotal, t.diskon, t.total, t.laba
                       FROM transaksi t WHERE $where ORDER BY t.tanggal ASC, t.id ASC");
    foreach ($st as $row) {
        $semua[] = [
            'tanggal'  => $row['tanggal'],
            'kode'     => $row['kode'],
            'metode'   => $row['metode'],
            'kasir'    => $row['kasir'],
            'subtotal' => (float)$row['subtotal'],
            'diskon'   => (float)$row['diskon'],
            'total'    => (float)$row['total'],
            'laba'     => (float)$row['laba'],
        ];
    }

    return [
        'periode' => $periode,
        'label'   => $label,
        'ringkasan' => [
            'omzet'   => $omzet,
            'jumlah'  => $jumlah,
            'laba'    => $laba,
            'produk'  => $produkTerjual,
            'rata'    => $jumlah > 0 ? round($omzet / $jumlah) : 0,
        ],
        'chart'    => $chart,
        'top'      => $top,
        'terakhir' => $terakhir,
        'semua'    => $semua,
    ];
}
