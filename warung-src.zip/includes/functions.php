<?php
/**
 * Kumpulan fungsi bantu Warung Kelontong POS
 */

/** Escape output HTML */
function e($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/* Polyfill mbstring (ekstensi mb_* tidak selalu terpasang) */
if (!function_exists('mb_strlen')) {
    function mb_strlen($s, $enc = null)
    {
        return strlen((string)$s);
    }
}

/** Format rupiah: 72000 -> "Rp 72.000" */
function rp($n): string
{
    return 'Rp ' . number_format((float)$n, 0, ',', '.');
}

/** Keluarkan respons JSON lalu hentikan eksekusi */
function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Baca body request JSON */
function body_json(): array
{
    $raw = file_get_contents('php://input');
    $d = json_decode($raw, true);
    return is_array($d) ? $d : [];
}

/** Pastikan folder exports/tmp tersedia */
function ensure_export_dirs(): void
{
    if (!is_dir(EXPORT_DIR)) {
        @mkdir(EXPORT_DIR, 0775, true);
    }
    if (!is_dir(TMP_DIR)) {
        @mkdir(TMP_DIR, 0775, true);
    }
}

/**
 * Migrasi ringan untuk instalasi lama: tambahkan kolom barcode
 * (dipakai fitur barcode scanner & manajemen produk).
 * Aman dipanggil berulang — hanya menjalankan ALTER sekali per request.
 */
function ensure_schema(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        $ada = $pdo->query("SHOW COLUMNS FROM produk LIKE 'barcode'")->fetch();
        if (!$ada) {
            $pdo->exec("ALTER TABLE produk
                ADD COLUMN barcode VARCHAR(64) NULL DEFAULT NULL AFTER satuan,
                ADD UNIQUE KEY idx_barcode (barcode)");
        }
    } catch (Throwable $e) {
        // biarkan aplikasi tetap jalan walau migrasi gagal (mis. db belum siap)
    }
}

/* ------------------------------------------------------------
 * Pengaturan (key-value)
 * ---------------------------------------------------------- */

$__settings_cache = null;

function default_settings(): array
{
    return [
        'toko_nama'       => 'Warung Kelontong',
        'toko_alamat'     => '',
        'toko_telp'       => '',
        'struk_footer'    => 'Terima kasih telah berbelanja!',
        'kasir_nama'      => 'Kasir',
        'printer_nama'    => 'POS-58 Thermal',
        'printer_lebar'   => '58',
        'auto_backup'     => '0',
        'backup_terakhir' => '',
    ];
}

function all_settings(): array
{
    global $__settings_cache;
    if (is_array($__settings_cache)) {
        return $__settings_cache;
    }
    $__settings_cache = default_settings();
    try {
        $rows = db()->query('SELECT kunci, nilai FROM pengaturan');
        foreach ($rows as $r) {
            $__settings_cache[$r['kunci']] = $r['nilai'];
        }
    } catch (Throwable $e) {
        // abaikan: installer / db belum siap
    }
    return $__settings_cache;
}

function get_setting(string $k, string $def = ''): string
{
    $a = all_settings();
    return isset($a[$k]) && $a[$k] !== '' ? (string)$a[$k] : $def;
}

function set_setting(string $k, string $v): void
{
    global $__settings_cache;
    $st = db()->prepare('INSERT INTO pengaturan (kunci, nilai) VALUES (?, ?) ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)');
    $st->execute([$k, $v]);
    if (is_array($__settings_cache)) {
        $__settings_cache[$k] = $v;
    }
}

/* ------------------------------------------------------------
 * Tanggal bahasa Indonesia
 * ---------------------------------------------------------- */

function hari_indo(int $n): string
{
    $h = [1 => 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
    return $h[$n] ?? '';
}

function bulan_indo(int $n): string
{
    $b = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
          'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return $b[$n] ?? '';
}

/** "2025-11-07 19:32:00" -> "Jumat, 7 November 2025" */
function tanggal_indo(string $dt, bool $denganJam = false): string
{
    $ts = strtotime($dt);
    if ($ts === false) {
        return $dt;
    }
    $out = hari_indo((int)date('N', $ts)) . ', ' . date('j', $ts) . ' ' . bulan_indo((int)date('n', $ts)) . ' ' . date('Y', $ts);
    if ($denganJam) {
        $out .= ' • ' . date('H:i', $ts);
    }
    return $out;
}

/* ------------------------------------------------------------
 * Struk / transaksi
 * ---------------------------------------------------------- */

/** Susun payload struk lengkap dari id transaksi */
function struk_payload(PDO $pdo, int $id): array
{
    $st = $pdo->prepare('SELECT * FROM transaksi WHERE id = ?');
    $st->execute([$id]);
    $t = $st->fetch();
    if (!$t) {
        return [];
    }

    $st = $pdo->prepare('SELECT nama_produk, satuan, harga_jual, qty, subtotal FROM transaksi_detail WHERE transaksi_id = ? ORDER BY id');
    $st->execute([$id]);
    $items = [];
    foreach ($st->fetchAll() as $d) {
        $items[] = [
            'nama'     => $d['nama_produk'],
            'satuan'   => $d['satuan'],
            'qty'      => (int)$d['qty'],
            'harga'    => (float)$d['harga_jual'],
            'subtotal' => (float)$d['subtotal'],
        ];
    }

    return [
        'id'        => (int)$t['id'],
        'kode'      => $t['kode'],
        'tanggal'   => $t['tanggal'],
        'kasir'     => $t['kasir'],
        'metode'    => $t['metode'],
        'items'     => $items,
        'subtotal'  => (float)$t['subtotal'],
        'diskon'    => (float)$t['diskon'],
        'total'     => (float)$t['total'],
        'bayar'     => (float)$t['bayar'],
        'kembalian' => (float)$t['kembalian'],
        'toko'      => [
            'nama'   => get_setting('toko_nama'),
            'alamat' => get_setting('toko_alamat'),
            'telp'   => get_setting('toko_telp'),
            'footer' => get_setting('struk_footer'),
        ],
    ];
}

/* ------------------------------------------------------------
 * Backup
 * ---------------------------------------------------------- */

/** Jalankan backup otomatis (sekali sehari) bila diaktifkan */
function maybe_auto_backup(): void
{
    try {
        ensure_export_dirs();
        if (get_setting('auto_backup') !== '1') {
            return;
        }
        $file = EXPORT_DIR . '/auto-backup-' . date('Ymd') . '.sql';
        if (file_exists($file)) {
            return;
        }
        require_once BASE_PATH . '/lib/backup.php';
        create_backup($file);
        set_setting('backup_terakhir', date('Y-m-d H:i:s'));
    } catch (Throwable $e) {
        // backup otomatis tidak boleh mengganggu halaman utama
    }
}
