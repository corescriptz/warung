<?php
/**
 * Layout kerangka halaman (HP: tab bar melayang · desktop: sidebar).
 * page_start($tab, $judul) ... page_end()
 * $tab: transaksi | produk | laporan | pengaturan
 */

function page_start(string $tab, string $judul): void
{
    $GLOBALS['APP_TAB'] = $tab;
    $s = all_settings();
    $v = APP_VERSION;
    ?><!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#F2F3FB" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#0C0D1C" media="(prefers-color-scheme: dark)">
<meta name="color-scheme" content="light dark">
<title><?= e($judul) ?> &mdash; <?= e($s['toko_nama']) ?></title>
<link rel="stylesheet" href="assets/css/style.css?v=<?= $v ?>.<?= @filemtime(__DIR__ . '/../assets/css/style.css') ?: 0 ?>">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0' stop-color='%235B5EF4'/%3E%3Cstop offset='.55' stop-color='%238B5CF6'/%3E%3Cstop offset='1' stop-color='%23EC4899'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='16' fill='url(%23g)'/%3E%3Cpath d='M20 24h24l-2.4 24a4 4 0 0 1-4 3.6H26.4a4 4 0 0 1-4-3.6L20 24z' fill='%23fff'/%3E%3Cpath d='M25 24v-4a7 7 0 0 1 14 0v4' stroke='%23fff' stroke-width='3.4' fill='none' stroke-linecap='round'/%3E%3C/svg%3E">
<script>window.APP = { lebar: <?= (int)$s['printer_lebar'] ?>, versi: '<?= e(APP_VERSION) ?>' };</script>
</head>
<body data-page="<?= e($tab) ?>">

<!-- Area struk khusus cetak (di luar shell) -->
<div id="printArea"></div>

<div class="shell">

    <main class="scroll" id="scrollArea">
<?php
}

function page_end(string $extraHtml = ''): void
{
    $tab = $GLOBALS['APP_TAB'] ?? '';
    $v = APP_VERSION;
    $svgCart = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M6 7h12l-1.2 11a2 2 0 0 1-2 1.8H9.2a2 2 0 0 1-2-1.8L6 7z" class="fill-on-active"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/></svg>';
    $svgBox = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z"/><path d="M4 7.5l8 4.5 8-4.5M12 12v9"/></svg>';
    $svgChart = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"><path d="M5 20V10M12 20V4M19 20v-7"/></svg>';
    $svgGear = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.03 1.56V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1.11-1.56 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.56-1.03H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.65 8.9a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34H9a1.7 1.7 0 0 0 1-1.55V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1.04 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87V9c.24.6.8 1 1.44 1H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.51.99z"/></svg>';
    $svgLogo = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8h12l-1 11a2 2 0 0 1-2 1.8H9A2 2 0 0 1 7 19L6 8z"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8"/></svg>';
    ?>
    </main>

    <nav class="tabbar" aria-label="Menu utama">
        <div class="tabbar-brand">
            <div class="brand-logo"><?= $svgLogo ?></div>
            <div class="brand-text"><b><?= e(all_settings()['toko_nama']) ?></b><span>Kasir &amp; Stok</span></div>
        </div>
        <div class="tabbar-in">
            <a href="index.php" class="tab<?= $tab === 'transaksi' ? ' active' : '' ?>"<?= $tab === 'transaksi' ? ' aria-current="page"' : '' ?>>
                <i class="tab-ico"><?= $svgCart ?></i><span>Transaksi</span>
            </a>
            <a href="produk.php" class="tab<?= $tab === 'produk' ? ' active' : '' ?>"<?= $tab === 'produk' ? ' aria-current="page"' : '' ?>>
                <i class="tab-ico"><?= $svgBox ?></i><span>Produk</span>
            </a>
            <a href="laporan.php" class="tab<?= $tab === 'laporan' ? ' active' : '' ?>"<?= $tab === 'laporan' ? ' aria-current="page"' : '' ?>>
                <i class="tab-ico"><?= $svgChart ?></i><span>Laporan</span>
            </a>
            <a href="pengaturan.php" class="tab<?= $tab === 'pengaturan' ? ' active' : '' ?>"<?= $tab === 'pengaturan' ? ' aria-current="page"' : '' ?>>
                <i class="tab-ico"><?= $svgGear ?></i><span>Pengaturan</span>
            </a>
        </div>
    </nav>

    <!-- Toast notifikasi -->
    <div class="toast" id="toast"></div>
</div>

<?php
    // Elemen tambahan di luar shell (dialog, overlay) sebelum skrip
    echo $extraHtml;
?>

<script src="assets/js/common.js?v=<?= $v ?>.<?= @filemtime(__DIR__ . '/../assets/js/common.js') ?: 0 ?>"></script>
<script src="assets/js/<?= e($tab) ?>.js?v=<?= $v ?>.<?= @filemtime(__DIR__ . '/../assets/js/' . $tab . '.js') ?: 0 ?>"></script>
</body>
</html>
<?php
}
