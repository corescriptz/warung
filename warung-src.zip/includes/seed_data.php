<?php
/**
 * Data awal (seed) untuk instalasi pertama.
 * Dipakai oleh install.php dan generator database.sql.
 */

function seed_data(): array
{
    $kategori = ['Sembako', 'Minuman', 'Snack', 'Rokok', 'Lainnya'];

    // [nama, kategori, satuan, harga_beli, harga_jual, stok, barcode]
    // Barcode contoh (format EAN-13, prefiks 899 = Indonesia). Kosongkan untuk
    // barang satuan/sembarang yang memang tidak berbarcode (beras, telur, LPG, dll).
    $produk = [
        ['Beras Pandan Wangi 5kg',   'Sembako',  'sak',    65000,  72000, 12, ''],
        ['Beras Ramos 5kg',          'Sembako',  'sak',    58000,  65000, 15, ''],
        ['Minyak Goreng 2x1L',       'Sembako',  'pouch',  34000,  39000, 8,  '8992753100123'],
        ['Gula Pasir 1kg',           'Sembako',  'kg',     15500,  18000, 20, ''],
        ['Telur Ayam 1kg',           'Sembako',  'kg',     26000,  29500, 18, ''],
        ['Kecap Manis Bango 135ml',  'Sembako',  'botol',  17500,  21000, 6,  '8991002104105'],
        ['Tepung Segitiga Biru 1kg', 'Sembako',  'kg',     12000,  14500, 10, '8991002102345'],
        ['Indomie Goreng',           'Sembako',  'pcs',    2800,   3500,  72, '8991002101234'],
        ['Aqua 600ml',               'Minuman',  'botol',  2800,   3500,  48, '8992696403018'],
        ['Teh Pucuk Harum 350ml',    'Minuman',  'botol',  3000,   4000,  36, '8993175630012'],
        ['Kopi Kapal Api Special',   'Minuman',  'sachet', 1500,   2000,  60, '8991001110034'],
        ['Susu Ultra Milk Coklat 250ml', 'Minuman', 'kotak', 5500, 7000,  24, '8998009010123'],
        ['Le Minerale 1500ml',       'Minuman',  'botol',  5000,   6500,  20, '8992696412027'],
        ['Chitato Sapi Panggang 68g', 'Snack',   'pcs',    8500,   11000, 15, '8991102000123'],
        ['Oreo Vanilla 133g',        'Snack',    'pcs',    7500,   9500,  18, '8992696407016'],
        ['SilverQueen Chunky Bar',   'Snack',    'pcs',    14000,  18000, 9,  '8993175203011'],
        ['Beng-Beng',                'Snack',    'pcs',    1500,   2000,  50, '8993175200119'],
        ['Tango Wafer Coklat',       'Snack',    'pcs',    8000,   10000, 14, '8993175200140'],
        ['Sampoerna Mild 12',        'Rokok',    'bks',    27000,  30500, 11, '8992821110123'],
        ['Gudang Garam Surya 12',    'Rokok',    'bks',    30000,  33500, 9,  '8992821120123'],
        ['Marlboro Red 20',          'Rokok',    'bks',    32000,  36500, 7,  '7622300861234'],
        ['Djarum Super 12',          'Rokok',    'bks',    28500,  31500, 10, '8992821140123'],
        ['Sabun Lifebuoy 250ml',     'Lainnya',  'botol',  14000,  17500, 12, '8999999101019'],
        ['Deterjen Rinso 800g',      'Lainnya',  'pcs',    18000,  22500, 10, '8999999520123'],
        ['Pasta Gigi Pepsodent 190g', 'Lainnya', 'pcs',    13000,  16500, 11, '8999999010123'],
        ['Baterai ABC AA (2 pcs)',   'Lainnya',  'pack',   7000,   9000,  20, '8999999300123'],
        ['Gas LPG 3kg',              'Lainnya',  'tabung', 18000,  22000, 6,  ''],
    ];

    $settings = [
        'toko_nama'       => 'Warung Beras Jaya',
        'toko_alamat'     => 'Jl. Merdeka No. 123, Jakarta',
        'toko_telp'       => '0812-3456-7890',
        'struk_footer'    => 'Terima kasih telah berbelanja!',
        'kasir_nama'      => 'Bu Rina',
        'printer_nama'    => 'POS-58 Thermal',
        'printer_lebar'   => '58',
        'auto_backup'     => '0',
        'backup_terakhir' => '',
    ];

    /*
     * Transaksi contoh 7 hari terakhir.
     * jam_lalu = berapa jam yang lalu transaksi terjadi.
     * bayar_mode: pas (uang pas), 5rb/10rb/20rb/50rb/100rb/200rb (dibulatkan ke atas).
     */
    $transaksi = [
        ['jam_lalu' => 1,   'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Bu Rina', 'items' => [['Kecap Manis Bango 135ml', 1]]],
        ['jam_lalu' => 2,   'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Bu Rina', 'items' => [['Aqua 600ml', 2], ['Kopi Kapal Api Special', 1]]],
        ['jam_lalu' => 3,   'metode' => 'Tunai', 'bayar_mode' => '50rb',  'kasir' => 'Andi',    'items' => [['Indomie Goreng', 5], ['Teh Pucuk Harum 350ml', 2]]],
        ['jam_lalu' => 5,   'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Bu Rina', 'items' => [['Beras Pandan Wangi 5kg', 1]]],
        ['jam_lalu' => 7,   'metode' => 'Tunai', 'bayar_mode' => '50rb',  'kasir' => 'Andi',    'items' => [['Sampoerna Mild 12', 1], ['Aqua 600ml', 1]]],
        ['jam_lalu' => 9,   'metode' => 'QRIS',  'bayar_mode' => 'pas',   'kasir' => 'Bu Rina', 'items' => [['Minyak Goreng 2x1L', 2]]],
        ['jam_lalu' => 11,  'metode' => 'Tunai', 'bayar_mode' => '5rb',   'kasir' => 'Andi',    'items' => [['Beng-Beng', 3], ['Oreo Vanilla 133g', 1]]],
        ['jam_lalu' => 20,  'metode' => 'Tunai', 'bayar_mode' => '100rb', 'kasir' => 'Bu Rina', 'items' => [['Gula Pasir 1kg', 2], ['Telur Ayam 1kg', 1]]],
        ['jam_lalu' => 23,  'metode' => 'Tunai', 'bayar_mode' => '50rb',  'kasir' => 'Andi',    'items' => [['Chitato Sapi Panggang 68g', 1], ['Susu Ultra Milk Coklat 250ml', 2]]],
        ['jam_lalu' => 26,  'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Bu Rina', 'items' => [['Indomie Goreng', 10]]],
        ['jam_lalu' => 30,  'metode' => 'QRIS',  'bayar_mode' => 'pas',   'kasir' => 'Andi',    'items' => [['Gudang Garam Surya 12', 1]]],
        ['jam_lalu' => 34,  'metode' => 'Tunai', 'bayar_mode' => '50rb',  'kasir' => 'Bu Rina', 'items' => [['Sabun Lifebuoy 250ml', 1], ['Pasta Gigi Pepsodent 190g', 1]]],
        ['jam_lalu' => 46,  'metode' => 'Tunai', 'bayar_mode' => '200rb', 'kasir' => 'Bu Rina', 'items' => [['Beras Ramos 5kg', 1], ['Minyak Goreng 2x1L', 1]]],
        ['jam_lalu' => 50,  'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Andi',    'items' => [['Le Minerale 1500ml', 2], ['Beng-Beng', 2]]],
        ['jam_lalu' => 54,  'metode' => 'Tunai', 'bayar_mode' => '50rb',  'kasir' => 'Bu Rina', 'items' => [['Deterjen Rinso 800g', 1], ['Baterai ABC AA (2 pcs)', 1]]],
        ['jam_lalu' => 58,  'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Andi',    'items' => [['Marlboro Red 20', 1], ['Aqua 600ml', 2]]],
        ['jam_lalu' => 70,  'metode' => 'Tunai', 'bayar_mode' => '100rb', 'kasir' => 'Bu Rina', 'items' => [['Telur Ayam 1kg', 2], ['Tepung Segitiga Biru 1kg', 1]]],
        ['jam_lalu' => 75,  'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Andi',    'items' => [['Kopi Kapal Api Special', 5]]],
        ['jam_lalu' => 80,  'metode' => 'Tunai', 'bayar_mode' => '50rb',  'kasir' => 'Bu Rina', 'items' => [['SilverQueen Chunky Bar', 1], ['Tango Wafer Coklat', 1]]],
        ['jam_lalu' => 94,  'metode' => 'QRIS',  'bayar_mode' => 'pas',   'kasir' => 'Andi',    'items' => [['Sampoerna Mild 12', 2]]],
        ['jam_lalu' => 100, 'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Bu Rina', 'items' => [['Gas LPG 3kg', 1], ['Aqua 600ml', 1]]],
        ['jam_lalu' => 118, 'metode' => 'Tunai', 'bayar_mode' => '50rb',  'kasir' => 'Bu Rina', 'items' => [['Djarum Super 12', 1], ['Teh Pucuk Harum 350ml', 2]]],
        ['jam_lalu' => 130, 'metode' => 'Tunai', 'bayar_mode' => '200rb', 'kasir' => 'Andi',    'items' => [['Beras Pandan Wangi 5kg', 2]]],
        ['jam_lalu' => 142, 'metode' => 'Tunai', 'bayar_mode' => 'pas',   'kasir' => 'Bu Rina', 'items' => [['Oreo Vanilla 133g', 2], ['Chitato Sapi Panggang 68g', 1], ['Susu Ultra Milk Coklat 250ml', 1]]],
    ];

    return [
        'kategori'  => $kategori,
        'produk'    => $produk,
        'settings'  => $settings,
        'transaksi' => $transaksi,
    ];
}
