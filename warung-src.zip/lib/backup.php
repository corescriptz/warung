<?php
/**
 * Backup database ke file .sql (tanpa exec/mysqldump).
 */

function create_backup(string $outfile): void
{
    $pdo = db();
    $tables = ['pengaturan', 'kategori', 'produk', 'transaksi', 'transaksi_detail', 'import_log'];

    $nl = "\n";
    $sql = '-- Backup ' . get_setting('toko_nama') . ' - ' . date('Y-m-d H:i:s') . $nl;
    $sql .= '-- Dibuat otomatis oleh Warung Kelontong POS' . $nl . $nl;
    $sql .= 'SET NAMES utf8mb4;' . $nl;
    $sql .= 'SET FOREIGN_KEY_CHECKS=0;' . $nl . $nl;

    foreach ($tables as $t) {
        $r = $pdo->query('SHOW CREATE TABLE `' . $t . '`')->fetch();
        if (!$r) {
            continue;
        }
        $sql .= 'DROP TABLE IF EXISTS `' . $t . '`;' . $nl;
        $sql .= $r['Create Table'] . ';' . $nl . $nl;

        $rows = $pdo->query('SELECT * FROM `' . $t . '`');
        $batch = [];
        while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
            $vals = [];
            foreach ($row as $v) {
                $vals[] = ($v === null) ? 'NULL' : $pdo->quote((string)$v);
            }
            $cols = '`' . implode('`,`', array_keys($row)) . '`';
            $batch[] = 'INSERT INTO `' . $t . '` (' . $cols . ') VALUES (' . implode(',', $vals) . ');';
            if (count($batch) >= 100) {
                $sql .= implode($nl, $batch) . $nl;
                $batch = [];
            }
        }
        if ($batch) {
            $sql .= implode($nl, $batch) . $nl;
        }
        $sql .= $nl;
    }

    $sql .= 'SET FOREIGN_KEY_CHECKS=1;' . $nl;

    $dir = dirname($outfile);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    file_put_contents($outfile, $sql);
}

/** Nama file backup ber-timestamp */
function backup_filename(string $prefix = 'backup'): string
{
    return $prefix . '-' . date('Ymd-His') . '.sql';
}
