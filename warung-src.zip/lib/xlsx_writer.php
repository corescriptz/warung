<?php
/**
 * XLSX Writer minimalis (tanpa dependensi eksternal).
 * Menghasilkan file .xlsx valid menggunakan ZipArchive bawaan PHP.
 *
 * Pemakaian:
 *   XlsxWriter::download('laporan.xlsx', [
 *     ['nama' => 'Ringkasan', 'widths' => [24, 18], 'rows' => [
 *         ['Periode', 'Hari Ini'],
 *         ['Omzet', 150000],
 *     ]],
 *   ]);
 */
class XlsxWriter
{
    /** Kirim file xlsx ke browser (download) */
    public static function download(string $filename, array $sheets): void
    {
        if (!class_exists('ZipArchive')) {
            http_response_code(500);
            header('Content-Type: text/plain; charset=utf-8');
            echo "Ekstensi PHP ZipArchive tidak tersedia di server ini.";
            exit;
        }
        $tmp = tempnam(sys_get_temp_dir(), 'xlsx_');
        self::save($tmp, $sheets);

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . rawurlencode($filename) . '"');
        header('Content-Length: ' . (string)filesize($tmp));
        header('Cache-Control: no-store');
        readfile($tmp);
        @unlink($tmp);
        exit;
    }

    /** Simpan workbook ke file */
    public static function save(string $path, array $sheets): void
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('Ekstensi PHP ZipArchive tidak tersedia.');
        }
        $sheets = array_values($sheets);
        if (!$sheets) {
            $sheets = [['nama' => 'Sheet1', 'rows' => []]];
        }

        $zip = new ZipArchive();
        // OVERWRITE|CREATE: OVERWRITE saja gagal bila file target belum ada
        if ($zip->open($path, ZipArchive::OVERWRITE | ZipArchive::CREATE) !== true) {
            throw new RuntimeException('Tidak dapat membuat file xlsx.');
        }

        // [Content_Types].xml
        $ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
        foreach ($sheets as $i => $s) {
            $ct .= '<Override PartName="/xl/worksheets/sheet' . ($i + 1) . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }
        $ct .= '</Types>';
        $zip->addFromString('[Content_Types].xml', $ct);

        // _rels/.rels
        $zip->addFromString('_rels/.rels',
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>');

        // xl/workbook.xml
        $wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>';
        foreach ($sheets as $i => $s) {
            $wb .= '<sheet name="' . self::esc(mb_compat((string)($s['nama'] ?? 'Sheet' . ($i + 1)))) . '" sheetId="' . ($i + 1) . '" r:id="rId' . ($i + 1) . '"/>';
        }
        $wb .= '</sheets></workbook>';
        $zip->addFromString('xl/workbook.xml', $wb);

        // xl/_rels/workbook.xml.rels
        $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
        foreach ($sheets as $i => $s) {
            $rels .= '<Relationship Id="rId' . ($i + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . ($i + 1) . '.xml"/>';
        }
        $rels .= '<Relationship Id="rId' . (count($sheets) + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>';
        $zip->addFromString('xl/_rels/workbook.xml.rels', $rels);

        // xl/styles.xml (font normal + bold, header baris pertama memakai s=1)
        $zip->addFromString('xl/styles.xml',
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<fonts count="2">'
            . '<font><sz val="11"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="11"/><name val="Calibri"/></font>'
            . '</fonts>'
            . '<fills count="2">'
            . '<fill><patternFill patternType="none"/></fill>'
            . '<fill><patternFill patternType="gray125"/></fill>'
            . '</fills>'
            . '<borders count="1"><border/></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="2">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
            . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>');

        // Worksheets
        foreach ($sheets as $i => $s) {
            $zip->addFromString('xl/worksheets/sheet' . ($i + 1) . '.xml', self::sheetXml($s));
        }

        $zip->close();
    }

    private static function sheetXml(array $sheet): string
    {
        $rows = $sheet['rows'] ?? [];
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';

        if (!empty($sheet['widths']) && is_array($sheet['widths'])) {
            $xml .= '<cols>';
            foreach ($sheet['widths'] as $ci => $w) {
                $xml .= '<col min="' . ($ci + 1) . '" max="' . ($ci + 1) . '" width="' . (float)$w . '" customWidth="1"/>';
            }
            $xml .= '</cols>';
        }

        $xml .= '<sheetData>';
        foreach ($rows as $ri => $row) {
            $r = $ri + 1;
            $xml .= '<row r="' . $r . '">';
            $ci = 0;
            foreach ((array)$row as $val) {
                $ref = self::colLetter($ci) . $r;
                $bold = ($ri === 0) ? ' s="1"' : '';
                if (is_int($val) || is_float($val)) {
                    $xml .= '<c r="' . $ref . '"' . $bold . '><v>' . (string)$val . '</v></c>';
                } elseif ($val === null || $val === '') {
                    // sel kosong: lewati
                } elseif (is_numeric($val) && strlen((string)$val) <= 15) {
                    $xml .= '<c r="' . $ref . '"' . $bold . '><v>' . (string)$val . '</v></c>';
                } else {
                    $xml .= '<c r="' . $ref . '" t="inlineStr"' . $bold . '><is><t xml:space="preserve">' . self::esc((string)$val) . '</t></is></c>';
                }
                $ci++;
            }
            $xml .= '</row>';
        }
        $xml .= '</sheetData></worksheet>';
        return $xml;
    }

    private static function colLetter(int $i): string
    {
        $s = '';
        $i++;
        while ($i > 0) {
            $m = ($i - 1) % 26;
            $s = chr(65 + $m) . $s;
            $i = intdiv($i - 1, 26);
        }
        return $s;
    }

    private static function esc(string $s): string
    {
        return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }
}

/** strtolower aman tanpa ekstensi mbstring (untuk teks ASCII/latin) */
function mb_compat(string $s): string
{
    return function_exists('mb_strtolower') ? mb_strtolower($s) : strtolower($s);
}
