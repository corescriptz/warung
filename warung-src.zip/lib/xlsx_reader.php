<?php
/**
 * XLSX / CSV Reader minimalis (tanpa dependensi eksternal).
 * Cukup untuk kebutuhan import data barang.
 *
 * XlsxReader::readAny('/path/file.xlsx')  -> array baris: [ ['Nama', 'Harga', ...], [...], ... ]
 * XlsxReader::readAny('/path/file.csv')
 */
class XlsxReader
{
    /**
     * Baca file .xlsx atau .csv.
     * Baris pertama diasumsikan baris header.
     * Nilai dikembalikan sebagai string / angka (null untuk sel kosong).
     */
    public static function readAny(string $path, string $ext): array
    {
        $ext = strtolower(ltrim($ext, '.'));
        if ($ext === 'csv' || $ext === 'txt') {
            return self::readCsv($path);
        }
        if ($ext === 'xlsx') {
            return self::readXlsx($path);
        }
        throw new RuntimeException('Format file tidak didukung. Gunakan .xlsx atau .csv');
    }

    /* ------------------------------------------------------------ */

    public static function readXlsx(string $path): array
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('Ekstensi PHP ZipArchive tidak tersedia di server ini.');
        }
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw new RuntimeException('File Excel tidak dapat dibuka. Pastikan file .xlsx valid.');
        }

        // 1. Shared strings
        $shared = [];
        $ss = $zip->getFromName('xl/sharedStrings.xml');
        if ($ss !== false && $ss !== '') {
            $x = @simplexml_load_string($ss);
            if ($x !== false) {
                foreach ($x->si as $si) {
                    $text = '';
                    if (isset($si->t)) {
                        $text = (string)$si->t;
                    } elseif (isset($si->r)) {
                        foreach ($si->r as $run) {
                            $text .= isset($run->t) ? (string)$run->t : '';
                        }
                    }
                    $shared[] = $text;
                }
            }
        }

        // 2. Sheet pertama
        $sheetName = 'xl/worksheets/sheet1.xml';
        if ($zip->locateName($sheetName, ZipArchive::FL_NOCASE) === false) {
            $sheetName = '';
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $n = (string)$zip->getNameIndex($i);
                if (preg_match('#xl/worksheets/sheet\d+\.xml$#i', $n)) {
                    $sheetName = $n;
                    break;
                }
            }
        }
        if ($sheetName === '') {
            $zip->close();
            throw new RuntimeException('Sheet Excel tidak ditemukan.');
        }
        $xmlStr = $zip->getFromName($sheetName);
        $zip->close();

        $xml = @simplexml_load_string($xmlStr);
        if ($xml === false) {
            throw new RuntimeException('Struktur file Excel tidak dapat dibaca.');
        }

        $rows = [];
        if (isset($xml->sheetData->row)) {
            foreach ($xml->sheetData->row as $row) {
                $cells = [];
                $maxIdx = -1;
                foreach ($row->c as $c) {
                    $ref = isset($c['r']) ? (string)$c['r'] : '';
                    $idx = $ref !== '' ? self::colIndex($ref) : count($cells);
                    $type = isset($c['t']) ? (string)$c['t'] : '';
                    $val = null;

                    if ($type === 's') {
                        $v = (int)(string)$c->v;
                        $val = isset($shared[$v]) ? $shared[$v] : null;
                    } elseif ($type === 'inlineStr') {
                        $val = isset($c->is->t) ? (string)$c->is->t : '';
                        if ($val === '' && isset($c->is->r)) {
                            foreach ($c->is->r as $run) {
                                $val .= isset($run->t) ? (string)$run->t : '';
                            }
                        }
                    } elseif ($type === 'b') {
                        $val = ((string)$c->v === '1') ? 'TRUE' : 'FALSE';
                    } elseif ($type === 'str') {
                        $val = (string)$c->v;
                    } else {
                        if (isset($c->v)) {
                            $raw = (string)$c->v;
                            $val = is_numeric($raw) ? $raw + 0 : $raw;
                        }
                    }
                    $cells[$idx] = $val;
                    $maxIdx = max($maxIdx, $idx);
                }
                if ($maxIdx < 0) {
                    continue; // baris benar-benar kosong
                }
                $line = [];
                for ($i = 0; $i <= $maxIdx; $i++) {
                    $line[$i] = isset($cells[$i]) ? $cells[$i] : null;
                }
                $rows[] = $line;
            }
        }

        return self::bersihkan($rows);
    }

    public static function readCsv(string $path): array
    {
        $fh = fopen($path, 'r');
        if (!$fh) {
            throw new RuntimeException('File CSV tidak dapat dibuka.');
        }
        $rows = [];
        $delimiter = ',';
        $first = (string)fgets($fh);
        // deteksi delimiter sederhana
        $semi = substr_count($first, ';');
        $koma = substr_count($first, ',');
        $tab  = substr_count($first, "\t");
        if ($semi > $koma && $semi >= $tab) {
            $delimiter = ';';
        } elseif ($tab > $koma && $tab > $semi) {
            $delimiter = "\t";
        }
        rewind($fh);

        while (($data = fgetcsv($fh, 0, $delimiter)) !== false) {
            $line = [];
            $kosong = true;
            foreach ($data as $i => $v) {
                $v = ($v === null) ? null : trim((string)$v);
                if ($v !== null && $v !== '') {
                    $kosong = false;
                }
                $line[$i] = $v;
            }
            if ($kosong) {
                continue;
            }
            $rows[] = $line;
        }
        fclose($fh);
        return self::bersihkan($rows);
    }

    /** Buang baris yang semua selnya kosong & rapikan urutan indeks */
    private static function bersihkan(array $rows): array
    {
        $out = [];
        foreach ($rows as $row) {
            $ada = false;
            foreach ($row as $v) {
                if ($v !== null && trim((string)$v) !== '') {
                    $ada = true;
                    break;
                }
            }
            if ($ada) {
                $out[] = array_values($row);
            }
        }
        return $out;
    }

    /** "BC12" -> 54 (indeks kolom 0-based) */
    private static function colIndex(string $ref): int
    {
        preg_match('/^([A-Z]+)/i', $ref, $m);
        if (empty($m[1])) {
            return 0;
        }
        $letters = strtoupper($m[1]);
        $n = 0;
        for ($i = 0, $l = strlen($letters); $i < $l; $i++) {
            $n = $n * 26 + (ord($letters[$i]) - 64);
        }
        return $n - 1;
    }
}
