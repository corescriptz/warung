<?php
/**
 * Barcode Code128-B -> SVG. Murni PHP, tanpa library eksternal.
 *
 * Dipakai oleh cetak-label.php. Karena Code128 bisa menampung huruf & angka
 * dengan panjang bebas, semua kode di kolom `produk.barcode` bisa dicetak
 * apa adanya dan terbaca persis sama oleh scanner.
 */

if (!defined('BASE_PATH')) {
    exit('Akses langsung tidak diizinkan.');
}

/**
 * Tabel pola garis Code 128 standar (lebar modul bar-space bergantian,
 * dimulai dari bar). Indeks 0-102 pola data, 103-105 Start A/B/C, 106 Stop.
 */
function bc128_patterns(): array
{
    return [
        '212222', '222122', '222221', '121223', '121322', '131222', '122213',
        '122312', '132212', '221213', '221312', '231212', '112232', '122132',
        '122231', '113222', '123122', '123221', '223211', '221132', '221231',
        '213212', '223112', '312131', '311222', '321122', '321221', '312212',
        '322112', '322211', '212123', '212321', '232121', '111323', '131123',
        '131321', '112313', '132113', '132311', '211313', '231113', '231311',
        '112133', '112331', '132131', '113123', '113321', '133121', '313121',
        '211331', '231131', '213113', '213311', '213131', '311123', '311321',
        '331121', '312113', '312311', '332111', '314111', '221411', '431111',
        '111224', '111422', '121124', '121421', '141122', '141221', '112214',
        '112412', '122114', '122411', '142112', '142211', '241211', '221114',
        '413111', '241112', '134111', '111242', '121142', '121241', '114212',
        '124112', '124211', '411212', '421112', '421211', '212141', '214121',
        '412121', '111143', '111341', '131141', '114113', '114311', '411113',
        '411311', '113141', '114131', '311141', '411131',
        '211412', '211214', '211232',           // 103 Start A, 104 Start B, 105 Start C
        '2331112',                              // 106 Stop (13 modul)
    ];
}

/**
 * Bersihkan kode agar valid untuk Code128-B (ASCII 32-126).
 * Barcode selalu ASCII, jadi pakai fungsi string biasa (tanpa mb_*).
 */
function bc128_sanitize(string $kode): string
{
    $kode = trim($kode);
    $out = '';
    $n = strlen($kode);
    for ($i = 0; $i < $n; $i++) {
        $o = ord($kode[$i]);
        if ($o >= 32 && $o <= 126) {
            $out .= $kode[$i];
        }
    }
    return $out;
}

/**
 * Render barcode Code128-B menjadi tag <svg> (satuan mm, vektor = tajam di segala printer).
 *
 * @param string $kode   Isi barcode.
 * @param float  $hMm    Tinggi garis dalam mm.
 * @param float  $maxWMm Lebar maksimum yang tersedia (mm), modul menyesuaikan otomatis.
 * @param string $warna  Warna garis.
 */
function barcode_svg(string $kode, float $hMm, float $maxWMm, string $warna = '#000'): string
{
    $kode = bc128_sanitize($kode);
    if ($kode === '') {
        return '';
    }

    $pat = bc128_patterns();

    // Start B (104) + nilai tiap karakter (ord - 32) + Stop (106)
    $seq = [104];
    $n = strlen($kode);
    for ($i = 0; $i < $n; $i++) {
        $seq[] = ord($kode[$i]) - 32;
    }
    // Check digit
    $sum = 104;
    for ($i = 1; $i < count($seq); $i++) {
        $sum += $seq[$i] * $i;
    }
    $seq[] = $sum % 103;
    $seq[] = 106;

    // Hitung total modul (termasuk quiet zone 7 modul tiap sisi)
    $totalMod = 14; // quiet zone kiri + kanan
    foreach ($seq as $v) {
        $totalMod += strlen($pat[$v]);
    }

    $modul = min(0.375, $maxWMm / $totalMod);
    $wMm = $totalMod * $modul;

    // Susun <rect> untuk tiap bar
    $rects = '';
    $x = 7 * $modul; // mulai setelah quiet zone kiri
    foreach ($seq as $idx => $v) {
        $w = strlen($pat[$v]);
        for ($j = 0; $j < $w; $j++) {
            if ($j % 2 === 0) { // elemen genap = bar
                $bw = (float)$pat[$v][$j] * $modul;
                $rects .= '<rect x="' . number_format($x, 3, '.', '') . '" y="0" width="'
                    . number_format($bw, 3, '.', '') . '" height="' . number_format($hMm, 2, '.', '') . '"/>';
            }
            $x += (float)$pat[$v][$j] * $modul;
        }
    }

    return '<svg class="bc-svg" xmlns="http://www.w3.org/2000/svg" width="'
        . number_format($wMm, 2, '.', '') . 'mm" height="' . number_format($hMm, 2, '.', '')
        . 'mm" viewBox="0 0 ' . number_format($wMm, 3, '.', '') . ' ' . number_format($hMm, 2, '.', '')
        . '" preserveAspectRatio="none" shape-rendering="crispEdges" fill="' . e($warna) . '">' . $rects . '</svg>';
}

/**
 * Kode internal otomatis, contoh: WK251107-4821 (WK + yyMMdd + 4 digit acak).
 */
function bc128_kode_otomatis(): string
{
    return 'WK' . date('ymd') . '-' . str_pad((string)random_int(0, 9999), 4, '0', STR_PAD_LEFT);
}
